PROBLEM CHILD — a party game about inventing solutions to other people's problems
===================================================================================

HOW TO PLAY (no installs, no accounts)
---------------------------------------
1. Send this whole "invention-party" folder to your friends (zip it up, AirDrop
   it, Google Drive, whatever). Everyone needs their own copy of the folder.
2. Everyone double-clicks index.html to open it in their browser (Chrome,
   Edge, or Firefox all work well).
3. One person clicks "Create Game" and gets a 4-letter code.
4. Everyone else types their name + that code and clicks "Join."
5. The host picks a number of rounds and clicks "Start Game."

Then each round: everyone secretly writes a problem -> everyone gets someone
else's problem (never their own) -> everyone draws + names + prices an
invention that solves it -> inventions are revealed anonymously -> everyone
votes (you can't vote for your own) -> creators are revealed -> points are
added -> leaderboard -> next round -> final winner.

HOW THE MULTIPLAYER ACTUALLY WORKS
-------------------------------------
There's no dedicated backend server you need to run. Each player's browser
connects directly to the host's browser over a real-time connection
(WebRTC), and the two browsers just find each other through PeerJS's free,
public "phone book" service (a small piece of infrastructure PeerJS runs so
strangers' browsers can discover each other — it doesn't see or store your
game data, it just helps set up the direct connection).

That means:
- The HOST'S TAB is the "referee" for the whole game. All game rules
  (assigning problems, preventing self-votes, tallying scores) are enforced
  there, and the game only keeps running while that tab stays open.
- If the host closes their tab or loses internet, the game session ends.
  Everyone would need to start a new game.
- If a regular player's tab closes, they just drop out — the game can
  continue with the players who are still connected once everyone left has
  submitted whatever's needed for the current phase.
- This is genuinely different-computer, different-network multiplayer — it
  works over the regular internet, not just on the same WiFi.

RELIABILITY NOTES
--------------------
- PeerJS's free public broker is a community service, not something with an
  uptime guarantee. It's normally solid, but if it's ever having a bad day,
  "Create Game" may fail to get a connection — just try again in a minute.
- Very locked-down networks (strict corporate/school firewalls) can
  sometimes block the peer-to-peer connection entirely. Home WiFi, phone
  hotspots, and normal home/office internet all work fine.
- If you want more control/reliability long-term, you can run your own free
  PeerServer instead of the public one (search "PeerJS PeerServer self
  host") and change the Peer() setup in js/net.js to point at it — this
  folder doesn't require that, it's just an option.

TITLE SCREEN
---------------
Your video and music are already included in the assets folder — nothing
to add. Just open index.html and the title screen plays automatically:
the video starts immediately, the menu buttons fade in at the 5-second
mark, and it keeps looping the music until you click PLAY.

Note: your video is 9.25 seconds long, so there's only a few seconds of
motion after the buttons fade in before it holds on its last frame — this
is expected and matches the intended behavior (the screen never goes
blank, it just stops on that final frame).

BUG FIX: TYPING/DRAWING DURING A TIMER
------------------------------------------
Earlier builds re-rendered the whole screen every time the countdown ticked
(about once a second), which wiped out whatever you were mid-typing in the
problem box or mid-drawing on the canvas. That's fixed — the timer now
patches in place without touching the rest of the screen, so typing and
drawing work normally even with a countdown running.

SOUND EFFECTS
-----------------
Button clicks, hovers, joining/leaving, game start, submissions, voting,
timer warnings, and winning all have short sound effects. These are
synthesized on the spot (no audio files involved), so there's nothing extra
to download and every sound is original. Each player can turn their own
sound on/off from the ⚙ Game Settings panel — it's a personal preference,
not something the host controls, since it doesn't affect gameplay.

TITLE SCREEN BACKGROUND: NORMAL OR CLASSIC
------------------------------------------------
From the title screen's own SETTINGS button, you can switch the background
between:
- Normal (the default) — a purple/gold gradient background with the
  "PROBLEM SOLVED!" title at the top and the menu buttons stacked
  vertically beneath it.
- Classic — your intro video plays, with the menu buttons appearing near
  the bottom about 5 seconds in, the way the original cinematic version
  worked.
This choice is saved per-device (each player can pick their own), and only
affects the title screen — nothing about the game itself changes.

COLOR THEMES
---------------
The app has six named color themes, each its own primary/secondary color
pair with its own visual identity (not just one universal purple/gold
scheme):

  Electric          purple + warm yellow    (the original look)
  Workshop          blue + orange           (default the first time you open it)
  Garden            green + cream
  Arcade            red + cyan
  Pop               pink + soft purple
  Classic Workshop  brown + warm gold
  Seafoam           seafoam teal + coral
  Safari            olive green + bright orange
  Tech              charcoal + lime green
  Monochrome        light gray + gray (intentionally colorless)

Pick one from the ⇄ THEME section of the title screen's own SETTINGS panel
— it shows the current theme as a preview card (the two colors, plus its
name); tap the card to open a dropdown of all six. Each theme's secondary
color becomes the main highlight color (buttons, timers, prices) and its
primary becomes the structural color (borders, secondary buttons) — the
small ⇄ button next to the preview swaps which is which, independently
per theme, and updates the whole app immediately: buttons, borders,
highlights, timers, presentation/voting UI, the leaderboard, hover states,
all of it.

Backgrounds, surfaces, and borders aren't hand-picked per theme — they're
derived automatically from each theme's primary color, so switching themes
tints the whole app toward that color's hue rather than sitting on one
fixed gray. The one deliberate exception is Garden's cream: pale/cream-like
colors are never darkened for dark mode (a "dark cream" just turns to mud),
so it's used as-is in both Dark and Light.

Electric is listed first in the picker as a nod to the game's original
color scheme, but Workshop is the actual default the very first time
someone opens the game.

ICONS & APPEARANCE
----------------------
Functional icons (settings, mute, pen/eraser/undo/redo/clear, close
buttons, the settings-panel category icons) are drawn as simple flat
line-art rather than emoji, so they look consistent across every device
and browser instead of however that person's OS happens to render emoji.
A couple of purely celebratory moments (the trophy on the winner screen,
the palette on the "get ready" presentation placeholder) are kept as
emoji on purpose — those are flourishes, not functional UI.

From the title screen's own SETTINGS button, each player can also choose
their own Sound Effects on/off and Dark or Light appearance (shown right
below the Theme picker) — this covers both the title screen menu and the
main game. Theme, Sound, and Appearance are all saved to this browser's
local storage, so they're remembered next time without needing to be set
again, and they're per-device: nothing here affects what anyone else sees,
even in the same multiplayer game.
Note: if you're using the video (Classic) title background, the video
itself obviously can't be relit — Dark/Light and the color theme there
only affect the menu panels and buttons on top of it, not the video
content.

INVENT & PRESENTATION LAYOUT
--------------------------------
Both the invention-design screen and the live presentation screen use a
wide two-column layout (drawing on one side, information on the other)
instead of one long stacked page — built to comfortably fit on a normal
desktop screen without scrolling, while still leaving the drawing canvas
big enough to actually draw on. Below about 840px wide, both automatically
collapse back to a single stacked column so nothing gets cut off or forces
sideways scrolling on a phone or small window. This is layout-only — the
drawing tools, submission rules, and the reveal/voting mechanics
underneath are unchanged.

GAME MODES
-------------
From the Game Settings panel, the host picks how the problem-writing phase
works, before starting the game:
- Classic — everyone writes their own problem in a free-form text box.
- Mad Libs — Blind — you're asked for words one at a time ("Give me a
  noun," "Give me a verb"...) with no idea what sentence they're going
  into. The finished sentence is revealed to you right after your last
  answer, as a little payoff, before it moves on to become someone else's
  problem to solve.
- Mad Libs — Live — same fill-in-the-blank idea, but the sentence is
  visible with blanks the whole time, filling in live as you type.

Templates are pulled from a small built-in bank, tagged by blank type
(noun, verb, adjective, place, animal, food). "Number of Prompts" picks
how many blanks a template has (5/7/10, or Custom — which snaps to
whichever of those three is closest, rather than generating an
arbitrary-length template on the fly).

GAME SETTINGS
----------------
There's a small Settings button in the corner of the game (once you've
created or joined a game) that opens a Game Settings panel, organized into
sections rather than one long list:
- Game Mode — Classic / Mad Libs Blind / Mad Libs Live, as large cards.
- Game Rules — the timers relevant to whichever mode is selected (Problem
  Time for Classic; Word Timer + Number of Prompts for either Mad Libs
  mode), plus Invention Time, Voting Time, and Number of Rounds.
- Presentation — Auto Reveal Speed (Fast/Normal/Slow, how quickly AUTO
  presentations pace themselves) and Presentation Time (the per-presenter
  timer that only applies if someone picks MANUAL).

Only the host can change any of this, and only while everyone's still in
the lobby — once the game starts, the panel locks so the rules can't shift
mid-game. Everyone else can still open the panel any time to see exactly
what's configured; it's clearly marked read-only for them.

When a timer's running, it's the HOST's clock that counts down and
broadcasts the remaining time to everyone once a second — nobody's
individual computer is doing its own countdown math, so there's no risk of
players seeing different numbers because their clocks drifted apart. If
time runs out on a phase, the game moves on automatically (unsubmitted
problems/inventions get a placeholder, unfinished manual presentations
reveal whatever's left and move to the next invention, and voting just
tallies whoever managed to vote in time).

SYNCHRONIZED PRESENTATIONS
------------------------------
Once everyone's inventions are in, the game doesn't just dump them on a
page to scroll through — it runs a shared, synchronized presentation.
Every player sees the exact same invention, at the exact same reveal step,
at the exact same time (drawing, then product, then name, then slogan,
then price). Creators stay completely anonymous until after voting closes.

AUTO vs. MANUAL is picked per invention, by whoever's invention is about
to be shown — not once globally by the host. When it's your turn, you get
asked "AUTO or MANUAL?" (without being told it's actually your own
invention, so the anonymity holds):
- AUTO — reveals each piece on its own pacing (speed set by the host's
  Auto Reveal Speed setting), no clicking needed.
- MANUAL — you control the reveal order yourself. If a Presentation Time
  limit is set, it applies here — your clock for your invention only.

If a presenter goes AFK (including never choosing a style at all), the
host has a small "skip to next invention" link at the bottom of the
presentation screen as a safety valve.

WHAT'S INTENTIONALLY SIMPLE
------------------------------
- Phase transitions after the reveal (opening voting, moving to the next
  round) are triggered by the host clicking a "Continue" button rather than
  an automatic timer — this keeps the flow reliable rather than racing a
  clock against slow typers/drawers.
- Host migration isn't implemented — if the host disconnects, the session
  ends rather than handing control to another player.
