// title.js — cinematic title screen: intro video (Classic mode), a text
// title screen (Normal mode, the default), music, timed button reveal, and
// a smooth handoff into the existing Create/Join menu. This only changes
// the ENTRY experience — it does not touch Net/Game/UI.

var Title = (function () {
  var screenEl, video, audio, muteBtn, buttonsEl, panelOverlay, panelBody;
  var buttonsShown = false;
  var musicPlaying = false;
  var bgStyle = 'text'; // 'text' (Normal, default) | 'video' (Classic)
  var themeDropdownOpen = false;

  var HOWTO_HTML =
    '<h2>How to Play</h2>' +
    '<p>Everyone secretly writes a ridiculous problem. The game swaps them ' +
    'around, so you never solve your own — you get a stranger\'s problem to fix.</p>' +
    '<p>Invent a product that solves it: draw it, name it, give it a slogan ' +
    'and a price tag. The sillier the better.</p>' +
    '<p>Every invention is revealed anonymously. Vote for your favorite — you ' +
    'can\'t vote for your own. Votes become points, and after all rounds the ' +
    'highest score wins.</p>';

  function init() {
    screenEl = document.getElementById('titleScreen');
    video = document.getElementById('titleVideo');
    audio = document.getElementById('titleMusic');
    muteBtn = document.getElementById('muteBtn');
    buttonsEl = document.getElementById('titleButtons');
    panelOverlay = document.getElementById('titlePanel');
    panelBody = document.getElementById('panelBody');
    document.getElementById('titlePanelCloseBtn').innerHTML = Icons.close();

    try {
      var stored = localStorage.getItem('titleBgStyle');
      if (stored === 'video' || stored === 'text') bgStyle = stored;
    } catch (e) { /* localStorage unavailable — default stays 'text' */ }
    applyBgStyle();

    if (bgStyle === 'video') {
      video.addEventListener('timeupdate', onTimeUpdate);
      // If the video is missing/unsupported, don't strand the player on a
      // blank screen forever — reveal the menu on a timer as a fallback.
      video.addEventListener('error', function () { revealButtons(); });
      setTimeout(function () { if (!buttonsShown) revealButtons(); }, 6000);
    } else {
      // Normal (text) mode has no video pacing to wait on — show the menu right away.
      revealButtons();
    }

    attemptMusic();
    ['click', 'keydown', 'touchstart'].forEach(function (evt) {
      document.addEventListener(evt, retryMusicOnce, { once: true, passive: true });
    });

    updateMuteIcon();
  }

  function onTimeUpdate() {
    if (!buttonsShown && video.currentTime >= 5) revealButtons();
  }

  function revealButtons() {
    buttonsShown = true;
    buttonsEl.classList.add('visible');
    video.removeEventListener('timeupdate', onTimeUpdate);
  }

  function attemptMusic() {
    var p = audio.play();
    if (p && p.catch) {
      p.then(function () { musicPlaying = true; updateMuteIcon(); })
        .catch(function () { musicPlaying = false; });
    }
  }
  function retryMusicOnce() {
    if (!musicPlaying) attemptMusic();
  }

  function toggleMute() {
    audio.muted = !audio.muted;
    if (!audio.muted && audio.paused) attemptMusic();
    updateMuteIcon();
  }
  function updateMuteIcon() {
    muteBtn.innerHTML = audio.muted ? Icons.speakerOff() : Icons.speakerOn();
  }

  // ---------------- BACKGROUND STYLE ----------------
  function applyBgStyle() {
    screenEl.classList.toggle('video-mode', bgStyle === 'video');
    if (bgStyle === 'video') {
      try { video.currentTime = 0; } catch (e) {}
      video.play().catch(function () {});
    } else {
      video.pause();
    }
  }

  function setBackgroundStyle(style) {
    bgStyle = style === 'video' ? 'video' : 'text';
    try { localStorage.setItem('titleBgStyle', bgStyle); } catch (e) {}
    applyBgStyle();
    if (!buttonsShown) revealButtons(); // don't leave the menu hidden if we just left video-timing mode
    renderSettingsPanel();
  }

  // ---------------- PANELS ----------------
  function settingsLabel(text, note) {
    return '<label style="display:block;font-size:12px;font-weight:700;letter-spacing:.04em;color:rgba(255,255,255,.6);margin:16px 0 8px;">' +
      text + (note ? ' <span style="font-weight:500;opacity:.65;">(' + note + ')</span>' : '') + '</label>';
  }

  function settingsLabel(text, note, isFirst) {
    return '<label class="title-panel-label' + (isFirst ? ' first' : '') + '">' +
      text + (note ? ' <span class="title-panel-label-note">(' + note + ')</span>' : '') + '</label>';
  }

  function renderSettingsPanel() {
    var html = '<h2>Settings</h2>';

    html += settingsLabel('TITLE SCREEN BACKGROUND', null, true);
    html += '<div class="title-bg-toggle">' +
      '<button class="pill' + (bgStyle === 'text' ? ' active' : '') + '" onclick="Title.setBackgroundStyle(\'text\')">' + Icons.image() + ' Normal</button>' +
      '<button class="pill' + (bgStyle === 'video' ? ' active' : '') + '" onclick="Title.setBackgroundStyle(\'video\')">' + Icons.play() + ' Classic</button>' +
      '</div>';

    var soundOn = SFX.isEnabled();
    html += settingsLabel('SOUND EFFECTS', 'just your device');
    html += '<div class="title-bg-toggle">' +
      '<button class="pill' + (soundOn ? ' active' : '') + '" onclick="Title.setSound(true)">On</button>' +
      '<button class="pill' + (!soundOn ? ' active' : '') + '" onclick="Title.setSound(false)">Off</button>' +
      '</div>';

    html += settingsLabel('THEME', 'just your device');
    html += renderThemePicker();

    var isLight = Theme.getShade() === 'light';
    html += settingsLabel('APPEARANCE', 'just your device');
    html += '<div class="title-bg-toggle">' +
      '<button class="pill' + (!isLight ? ' active' : '') + '" onclick="Title.setShade(\'dark\')">' + Icons.moon() + ' Dark</button>' +
      '<button class="pill' + (isLight ? ' active' : '') + '" onclick="Title.setShade(\'light\')">' + Icons.sun() + ' Light</button>' +
      '</div>';

    html += '<p style="margin-top:16px;">Rounds and phase timers are configured from the Settings ' +
      'panel in the corner of the game once you\'ve created or joined a ' +
      'game — only the host can change them, but everyone can see them.</p>' +
      '<p>Use the speaker icon in the corner of this title screen to mute or ' +
      'unmute the title music at any time — that\'s separate from the sound ' +
      'effects toggle above.</p>';
    panelBody.innerHTML = html;
  }

  // ---------------- THEME PICKER ----------------
  function swatchHTML(primary, secondary) {
    return '<span class="theme-swatch">' +
      '<span class="swatch-dot" style="background:' + primary + '"></span>' +
      '<span class="swatch-bar" style="background:linear-gradient(90deg,' + primary + ',' + secondary + ')"></span>' +
      '<span class="swatch-dot" style="background:' + secondary + '"></span>' +
      '</span>';
  }

  function renderThemePicker() {
    var key = Theme.getColorTheme();
    var c = Theme.colorsFor(key);
    var themeName = '';
    Theme.list().forEach(function (t) { if (t.key === key) themeName = t.name; });

    var html = '<div class="theme-picker">';
    html += '<div class="theme-preview-card" onclick="Title.toggleThemeDropdown()">' +
      swatchHTML(c.primary, c.secondary) +
      '<div class="theme-preview-info">' +
      '<div class="theme-preview-name">' + themeName + '</div>' +
      '</div>' +
      '<button class="theme-swap-btn" onclick="event.stopPropagation();Title.swapTheme();" title="Swap primary/secondary">&#8644;</button>' +
      '</div>';

    if (themeDropdownOpen) {
      html += '<div class="theme-dropdown">';
      Theme.list().forEach(function (t) {
        var selected = t.key === key;
        html += '<div class="theme-option' + (selected ? ' selected' : '') + '" onclick="Title.selectTheme(\'' + t.key + '\')">' +
          swatchHTML(t.primary, t.secondary) +
          '<span class="theme-option-name">' + t.name + '</span>' +
          (selected ? '<span class="theme-option-check">' + Icons.check() + '</span>' : '') +
          '</div>';
      });
      html += '</div>';
    }
    html += '</div>';
    return html;
  }

  function toggleThemeDropdown() {
    themeDropdownOpen = !themeDropdownOpen;
    renderSettingsPanel();
  }

  function selectTheme(key) {
    Theme.setColorTheme(key);
    themeDropdownOpen = false;
    renderSettingsPanel();
  }

  function swapTheme() {
    Theme.toggleSwap(Theme.getColorTheme());
    renderSettingsPanel();
  }

  function setSound(v) {
    SFX.setEnabled(v);
    renderSettingsPanel();
  }

  function setShade(mode) {
    Theme.setShade(mode);
    renderSettingsPanel();
  }

  function openPanel(which) {
    if (which === 'howto') { panelBody.innerHTML = HOWTO_HTML; }
    else { themeDropdownOpen = false; renderSettingsPanel(); }
    panelOverlay.classList.add('visible');
  }
  function closePanel() {
    panelOverlay.classList.remove('visible');
  }

  function goToPlayMenu() {
    screenEl.classList.add('fade-out');
    setTimeout(function () {
      screenEl.style.display = 'none';
      audio.pause();
    }, 550);
  }

  return {
    init: init,
    toggleMute: toggleMute,
    setBackgroundStyle: setBackgroundStyle,
    setSound: setSound,
    setShade: setShade,
    toggleThemeDropdown: toggleThemeDropdown,
    selectTheme: selectTheme,
    swapTheme: swapTheme,
    openPanel: openPanel,
    closePanel: closePanel,
    goToPlayMenu: goToPlayMenu
  };
})();
