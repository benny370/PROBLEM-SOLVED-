// drawing.js — the invention drawing canvas.

var Drawing = (function () {
  var canvas, ctx;
  var isDrawing = false;
  var tool = 'pen';
  var color = '#1a1a1a';
  var size = 6;
  var lastX = 0, lastY = 0;
  var history = [];
  var historyIndex = -1;

  function init(canvasEl) {
    canvas = canvasEl;
    ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    history = []; historyIndex = -1;
    pushHistory();

    canvas.addEventListener('pointerdown', start);
    canvas.addEventListener('pointermove', move);
    window.addEventListener('pointerup', end);
    canvas.addEventListener('pointerleave', function () { /* keep drawing until pointerup */ });
  }

  function getPos(e) {
    var r = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - r.left) * (canvas.width / r.width),
      y: (e.clientY - r.top) * (canvas.height / r.height)
    };
  }

  function start(e) {
    isDrawing = true;
    var p = getPos(e);
    lastX = p.x; lastY = p.y;
    drawSegment(p.x, p.y, true);
  }
  function move(e) {
    if (!isDrawing) return;
    var p = getPos(e);
    drawSegment(p.x, p.y, false);
  }
  function end() {
    if (isDrawing) { isDrawing = false; pushHistory(); }
  }

  function drawSegment(x, y, isDot) {
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
    ctx.fillStyle = ctx.strokeStyle;
    ctx.lineWidth = size;
    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(x, y);
    ctx.stroke();
    if (isDot) {
      ctx.beginPath();
      ctx.arc(x, y, size / 2, 0, Math.PI * 2);
      ctx.fill();
    }
    lastX = x; lastY = y;
  }

  function pushHistory() {
    historyIndex++;
    history.length = historyIndex;
    history.push(canvas.toDataURL());
    if (history.length > 40) { history.shift(); historyIndex--; }
  }

  function undo() { if (historyIndex > 0) { historyIndex--; restore(); } }
  function redo() { if (historyIndex < history.length - 1) { historyIndex++; restore(); } }
  function restore() {
    var img = new Image();
    img.onload = function () {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
    };
    img.src = history[historyIndex];
  }

  function clear() {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    pushHistory();
  }

  function setTool(t) { tool = t; }
  function setColor(c) { color = c; }
  function setSize(s) { size = s; }
  function exportPNG() { return canvas.toDataURL('image/png'); }

  return {
    init: init, undo: undo, redo: redo, clear: clear,
    setTool: setTool, setColor: setColor, setSize: setSize,
    exportPNG: exportPNG,
    canUndo: function () { return historyIndex > 0; },
    canRedo: function () { return historyIndex < history.length - 1; }
  };
})();
