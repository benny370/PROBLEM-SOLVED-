// game.js — game rules, phases, and the host-authoritative state machine.
// Message protocol between host and clients:
//   client -> host: JOIN {name}, SUBMIT_PROBLEM {text}, SUBMIT_INVENTION {drawing,product,name,slogan,price},
//                   CHOOSE_PRESENT_MODE {mode}, SHOW_FIELD {field}, NEXT_INVENTION {}, SUBMIT_VOTE {targetIndex}
//   host -> client: JOIN_OK {you}, JOIN_REJECTED {reason}, STATE {view}, KICKED {}
// Settings are host-only and locked once phase leaves 'lobby'.
// All timers are host-authoritative: the host ticks a setInterval and broadcasts the
// remaining seconds every second — clients never compute a countdown themselves, so
// there's no dependence on client clocks staying in sync.
//
// GAME MODE affects only how the "problem" phase collects each player's problem text:
//   'classic'       — free-form textarea (as before)
//   'madlibs_blind' — player answers word prompts one at a time without seeing the sentence
//   'madlibs_live'  — player fills the same blanks but sees the sentence build live
// In every mode, the end result is the same: one problem string per player, submitted
// via the same SUBMIT_PROBLEM message — Mad Libs modes just assemble that string
// client-side from a host-assigned template before sending it.
//
// PRESENTATION MODE (AUTO/MANUAL) is chosen per-invention by whoever is presenting it,
// not once globally by the host — each new presenter picks when it's their turn.

var COLORS = [
  { name: 'Red', hex: '#ff5c5c' },
  { name: 'Blue', hex: '#4d9fff' },
  { name: 'Green', hex: '#4ade80' },
  { name: 'Yellow', hex: '#ffd23f' },
  { name: 'Purple', hex: '#b26cff' },
  { name: 'Orange', hex: '#ff9f45' },
  { name: 'Pink', hex: '#ff6fb5' },
  { name: 'Cyan', hex: '#45e8e0' }
];

var PRESENT_FIELDS = ['drawing', 'product', 'name', 'slogan', 'price'];
var SETTING_KEYS = [
  'rounds', 'problemTimeSec', 'inventionTimeSec', 'presentationTimeSec', 'votingTimeSec',
  'gameMode', 'wordTimerSec', 'numPrompts', 'autoRevealSpeed'
];
var GAME_MODES = ['classic', 'madlibs_blind', 'madlibs_live'];
var AUTO_SPEEDS = { fast: 0.55, normal: 1, slow: 1.7 };

// Mad Libs template bank, grouped by blank count (matches the "Number of
// Prompts" setting). Each template's blanks array gives the type of each
// {N} token in order, used to prompt for/label that blank on the client.
var MADLIB_TEMPLATES = {
  5: [
    { blanks: ['noun', 'verb', 'noun', 'adjective', 'place'],
      text: 'My {0} keeps trying to {1} my {2}, and honestly it is getting pretty {3} near the {4}.' },
    { blanks: ['animal', 'place', 'food', 'verb', 'noun'],
      text: 'A {0} moved into my {1} and now demands {2} every time I try to {3} my {4}.' }
  ],
  7: [
    { blanks: ['noun', 'verb', 'adjective', 'place', 'animal', 'food', 'noun'],
      text: 'Every morning my {0} starts to {1}, which is {2}, so I hide in the {3} with a {4}, some {5}, and my {6}.' },
    { blanks: ['adjective', 'noun', 'verb', 'place', 'animal', 'food', 'noun'],
      text: 'My {0} {1} will not stop trying to {2} the {3}, so a {4} now guards my {5} while my {6} watches nervously.' }
  ],
  10: [
    { blanks: ['noun', 'verb', 'place', 'animal', 'adjective', 'food', 'noun', 'verb', 'adjective', 'place'],
      text: 'It started when my {0} tried to {1} the {2}, but a {3} got {4} and knocked over my {5}, so now my {6} refuses to {7} anywhere near the {8} {9}.' },
    { blanks: ['place', 'noun', 'verb', 'animal', 'food', 'adjective', 'noun', 'verb', 'noun', 'place'],
      text: 'Every time I visit the {0}, my {1} starts to {2}, which attracts a {3}, ruins my {4}, upsets my {5} {6}, and forces me to {7} with a {8} until the {9} closes.' }
  ]
};

function nearestPromptCount(n) {
  var options = [5, 7, 10];
  var best = options[0], bestDiff = Math.abs(n - options[0]);
  for (var i = 1; i < options.length; i++) {
    var d = Math.abs(n - options[i]);
    if (d < bestDiff) { best = options[i]; bestDiff = d; }
  }
  return best;
}

function pickMadlibTemplate(numPrompts) {
  var pool = MADLIB_TEMPLATES[nearestPromptCount(numPrompts)];
  var t = pool[Math.floor(Math.random() * pool.length)];
  return { text: t.text, blanks: t.blanks.slice() };
}

var Game = (function () {
  var state = null;       // host-side authoritative state
  var myView = null;      // latest personalized view (used by both host & client to render)
  var meId = null;        // my peerId
  var meName = '';
  var onUpdate = function () {};
  var autoTimer = null;      // host-side pending setTimeout for AUTO presentation pacing
  var timerInterval = null;  // host-side 1-second tick for the authoritative phase timer

  function setOnUpdate(fn) { onUpdate = fn; }

  // ---------- HOST: setup ----------
  function hostInit(hostName) {
    meId = Net.myPeerId();
    meName = hostName;
    state = {
      phase: 'lobby',
      hostId: meId,
      players: [{ id: meId, name: hostName, color: COLORS[0].hex, score: 0, connected: true, totalVotes: 0 }],
      settings: {
        rounds: 3, problemTimeSec: 0, inventionTimeSec: 0, presentationTimeSec: 0, votingTimeSec: 0,
        gameMode: 'classic', wordTimerSec: 0, numPrompts: 5, autoRevealSpeed: 'normal'
      },
      round: 0,
      problems: {},          // playerId -> text
      madlibAssignments: {}, // playerId -> {text, blanks} — only used when gameMode !== 'classic'
      assignments: {},       // solverId -> creatorId
      inventions: {},        // playerId -> {drawing,product,name,slogan,price}
      revealOrder: [],       // array of playerIds, shuffled — the presentation & voting order
      presentation: null,    // { mode, index, revealed:{...}, lastRevealedField, presenterId }
      votes: {},             // voterId -> targetPlayerId
      roundPoints: {},
      timer: null            // { remaining, total } — authoritative countdown, or null if untimed
    };
    pushStateToAll();
  }

  // ---------- HOST: settings ----------
  function hostUpdateSetting(key, value) {
    if (state.phase !== 'lobby') return; // locked once the game has started
    if (SETTING_KEYS.indexOf(key) === -1) return;
    if (key === 'rounds') {
      var n = parseInt(value, 10);
      if (!n || n < 1) return;
      state.settings.rounds = Math.min(n, 30);
    } else if (key === 'numPrompts') {
      var np = parseInt(value, 10);
      if (!np || np < 3) return;
      state.settings.numPrompts = Math.min(np, 20);
    } else if (key === 'gameMode') {
      if (GAME_MODES.indexOf(value) === -1) return;
      state.settings.gameMode = value;
    } else if (key === 'autoRevealSpeed') {
      if (AUTO_SPEEDS[value] === undefined) return;
      state.settings.autoRevealSpeed = value;
    } else {
      var secs = parseInt(value, 10);
      if (isNaN(secs) || secs < 0) return;
      state.settings[key] = secs;
    }
    pushStateToAll();
  }

  // ---------- HOST: authoritative timer engine ----------
  function stopTimer() {
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
    state.timer = null;
  }

  function startPhaseTimer(seconds, onExpire) {
    stopTimer();
    if (!seconds || seconds <= 0) return; // "No Timer"
    state.timer = { remaining: seconds, total: seconds };
    timerInterval = setInterval(function () {
      if (!state.timer) { clearInterval(timerInterval); timerInterval = null; return; }
      state.timer.remaining--;
      if (state.timer.remaining <= 0) {
        clearInterval(timerInterval);
        timerInterval = null;
        state.timer = null;
        onExpire();
      } else {
        pushStateToAll();
      }
    }, 1000);
  }

  function nextColor() {
    var used = state.players.map(function (p) { return p.color; });
    for (var i = 0; i < COLORS.length; i++) {
      if (used.indexOf(COLORS[i].hex) === -1) return COLORS[i].hex;
    }
    return COLORS[state.players.length % COLORS.length].hex;
  }

  function uniqueName(name) {
    var base = name.trim().slice(0, 18) || 'Player';
    var candidate = base;
    var n = 2;
    while (state.players.some(function (p) { return p.name.toLowerCase() === candidate.toLowerCase(); })) {
      candidate = base + ' (' + n + ')';
      n++;
    }
    return candidate;
  }

  // ---------- HOST: message handling ----------
  function hostHandleMessage(peerId, msg) {
    if (msg.type === 'JOIN') {
      if (state.phase !== 'lobby') {
        Net.sendTo(peerId, { type: 'JOIN_REJECTED', reason: 'This game has already started.' });
        return;
      }
      if (state.players.length >= 8) {
        Net.sendTo(peerId, { type: 'JOIN_REJECTED', reason: 'This game is full (8 players max).' });
        return;
      }
      var name = uniqueName(msg.name || 'Player');
      state.players.push({ id: peerId, name: name, color: nextColor(), score: 0, connected: true, totalVotes: 0 });
      Net.sendTo(peerId, { type: 'JOIN_OK', you: { id: peerId, name: name } });
      pushStateToAll();
      return;
    }

    var player = state.players.filter(function (p) { return p.id === peerId; })[0];
    if (!player) return;

    if (msg.type === 'SUBMIT_PROBLEM' && state.phase === 'problem') {
      if (state.problems[peerId]) return; // no resubmits
      var text = (msg.text || '').trim().slice(0, 260);
      if (!text) return;
      state.problems[peerId] = text;
      checkAllProblemsIn();
      pushStateToAll();
    }

    if (msg.type === 'SUBMIT_INVENTION' && state.phase === 'invent') {
      if (state.inventions[peerId]) return;
      var inv = {
        drawing: msg.drawing || '',
        product: (msg.product || '').trim().slice(0, 80),
        name: (msg.name || '').trim().slice(0, 60),
        slogan: (msg.slogan || '').trim().slice(0, 100),
        price: (msg.price || '').trim().slice(0, 30)
      };
      if (!inv.drawing || !inv.product || !inv.name) return; // require the essentials
      state.inventions[peerId] = inv;
      checkAllInventionsIn();
      pushStateToAll();
    }

    if (msg.type === 'CHOOSE_PRESENT_MODE' && state.phase === 'presenting' && state.presentation &&
        !state.presentation.mode && peerId === state.presentation.presenterId) {
      var mode = msg.mode === 'manual' ? 'manual' : 'auto';
      state.presentation.mode = mode;
      if (mode === 'manual') startPhaseTimer(state.settings.presentationTimeSec, onPresentationTimeExpire);
      pushStateToAll();
      if (mode === 'auto') scheduleAutoStep();
    }

    if (msg.type === 'SHOW_FIELD' && state.phase === 'presenting' && state.presentation &&
        state.presentation.mode === 'manual' && peerId === state.presentation.presenterId) {
      revealField(msg.field);
    }

    if (msg.type === 'NEXT_INVENTION' && state.phase === 'presenting' && state.presentation &&
        state.presentation.mode === 'manual' && peerId === state.presentation.presenterId) {
      var allShown = PRESENT_FIELDS.every(function (f) { return state.presentation.revealed[f]; });
      if (allShown) advancePresentation();
    }

    if (msg.type === 'SUBMIT_VOTE' && state.phase === 'vote') {
      if (state.votes[peerId] !== undefined) return; // locked once voted
      var targetId = state.revealOrder[msg.targetIndex];
      if (!targetId) return;
      if (targetId === peerId) return; // server-enforced: cannot vote for yourself
      state.votes[peerId] = targetId;
      checkAllVotesIn();
      pushStateToAll();
    }
  }

  function connectedPlayers() {
    return state.players.filter(function (p) { return p.connected; });
  }

  // ---------- PROBLEM PHASE ----------
  function assignMadlibTemplatesIfNeeded() {
    state.madlibAssignments = {};
    if (state.settings.gameMode === 'classic') return;
    connectedPlayers().forEach(function (p) {
      state.madlibAssignments[p.id] = pickMadlibTemplate(state.settings.numPrompts);
    });
  }

  function currentProblemPhaseTimerSec() {
    return state.settings.gameMode === 'classic' ? state.settings.problemTimeSec : state.settings.wordTimerSec;
  }

  function checkAllProblemsIn() {
    var everyone = connectedPlayers();
    var allIn = everyone.every(function (p) { return !!state.problems[p.id]; });
    if (allIn && everyone.length >= 2) assignProblems();
  }

  function onProblemTimeExpire() {
    connectedPlayers().forEach(function (p) {
      if (!state.problems[p.id]) state.problems[p.id] = '(no problem submitted — time ran out)';
    });
    assignProblems();
    pushStateToAll({ timerExpired: true });
  }

  function assignProblems() {
    // Cyclic shuffle: shuffled[i] solves shuffled[i-1]'s problem. A rotation
    // by any non-zero amount on a shuffled order has no fixed points, so
    // nobody ever receives their own problem.
    stopTimer();
    var ids = connectedPlayers().map(function (p) { return p.id; });
    shuffle(ids);
    state.assignments = {};
    for (var i = 0; i < ids.length; i++) {
      var solver = ids[i];
      var creator = ids[(i - 1 + ids.length) % ids.length];
      state.assignments[solver] = creator;
    }
    state.inventions = {};
    state.phase = 'invent';
    startPhaseTimer(state.settings.inventionTimeSec, onInventionTimeExpire);
  }

  function checkAllInventionsIn() {
    var everyone = connectedPlayers();
    var allIn = everyone.every(function (p) { return !!state.inventions[p.id]; });
    if (allIn) finishInventionPhase();
  }

  function onInventionTimeExpire() {
    connectedPlayers().forEach(function (p) {
      if (!state.inventions[p.id]) {
        state.inventions[p.id] = { drawing: '', product: '(no invention submitted)', name: '(no invention submitted)', slogan: '', price: '' };
      }
    });
    finishInventionPhase();
    pushStateToAll({ timerExpired: true });
  }

  function finishInventionPhase() {
    stopTimer();
    var ids = connectedPlayers().map(function (p) { return p.id; });
    shuffle(ids);
    state.revealOrder = ids;
    // No host-picked global mode anymore — go straight into presenting, and
    // let the first presenter choose AUTO/MANUAL for their own invention.
    state.presentation = { index: 0, revealed: blankRevealed(), lastRevealedField: null, presenterId: ids[0], mode: null };
    state.phase = 'presenting';
  }

  // ---------- PRESENTATION ENGINE ----------
  function blankRevealed() {
    return { drawing: false, product: false, name: false, slogan: false, price: false };
  }

  function revealField(field) {
    if (PRESENT_FIELDS.indexOf(field) === -1) return;
    if (state.presentation.revealed[field]) return; // no double-reveal
    state.presentation.revealed[field] = true;
    state.presentation.lastRevealedField = field;
    pushStateToAll();
  }

  function scheduleAutoStep() {
    clearTimeout(autoTimer);
    if (state.phase !== 'presenting' || !state.presentation || state.presentation.mode !== 'auto') return;
    var mult = AUTO_SPEEDS[state.settings.autoRevealSpeed] || 1;
    var revealed = state.presentation.revealed;
    var nextField = PRESENT_FIELDS.filter(function (f) { return !revealed[f]; })[0];
    if (nextField) {
      var delay = (nextField === 'drawing' ? 700 : 1300) * mult;
      autoTimer = setTimeout(function () {
        if (state.phase !== 'presenting' || !state.presentation) return;
        revealField(nextField);
        scheduleAutoStep();
      }, delay);
    } else {
      autoTimer = setTimeout(function () {
        if (state.phase !== 'presenting' || !state.presentation) return;
        advancePresentation();
      }, 2200 * mult);
    }
  }

  function onPresentationTimeExpire() {
    // Manual presenter ran out of time: reveal whatever's left, hold briefly, then move on.
    if (!state.presentation) return;
    PRESENT_FIELDS.forEach(function (f) { state.presentation.revealed[f] = true; });
    state.presentation.lastRevealedField = null;
    pushStateToAll({ timerExpired: true });
    setTimeout(function () {
      if (state.phase === 'presenting') advancePresentation();
    }, 1500);
  }

  function advancePresentation() {
    clearTimeout(autoTimer);
    stopTimer();
    var nextIndex = state.presentation.index + 1;
    if (nextIndex >= state.revealOrder.length) {
      state.presentation = null;
      state.phase = 'vote';
      startPhaseTimer(state.settings.votingTimeSec, onVoteTimeExpire);
      pushStateToAll();
      return;
    }
    state.presentation = {
      index: nextIndex,
      revealed: blankRevealed(),
      lastRevealedField: null,
      presenterId: state.revealOrder[nextIndex],
      mode: null // the new presenter picks AUTO/MANUAL for their own invention
    };
    pushStateToAll();
  }

  function hostForceNextInvention() {
    // Safety valve: lets the host skip a stalled/disconnected presenter
    // (including one who never chose AUTO/MANUAL).
    if (state.phase !== 'presenting' || !state.presentation) return;
    advancePresentation();
  }

  function checkAllVotesIn() {
    var everyone = connectedPlayers();
    var allIn = everyone.every(function (p) { return state.votes[p.id] !== undefined; });
    if (allIn) tallyVotes();
  }

  function onVoteTimeExpire() {
    tallyVotes();
    pushStateToAll({ timerExpired: true });
  }

  function tallyVotes() {
    stopTimer();
    state.roundPoints = {};
    state.players.forEach(function (p) { state.roundPoints[p.id] = 0; });
    Object.keys(state.votes).forEach(function (voterId) {
      var targetId = state.votes[voterId];
      state.roundPoints[targetId] = (state.roundPoints[targetId] || 0) + 1;
    });
    state.players.forEach(function (p) {
      p.score += (state.roundPoints[p.id] || 0);
      p.totalVotes += (state.roundPoints[p.id] || 0);
    });
    state.phase = 'creatorReveal';
  }

  function shuffle(arr) {
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
  }

  // ---------- HOST: host-driven controls ----------
  function hostStartGame() {
    if (connectedPlayers().length < 2) return;
    stopTimer();
    state.round = 1;
    state.problems = {}; state.assignments = {}; state.inventions = {};
    state.revealOrder = []; state.presentation = null; state.votes = {}; state.roundPoints = {};
    assignMadlibTemplatesIfNeeded();
    state.phase = 'problem';
    startPhaseTimer(currentProblemPhaseTimerSec(), onProblemTimeExpire);
    pushStateToAll();
  }

  function hostAdvance() {
    // Manual "continue" transitions the host controls: creatorReveal -> leaderboard
    // -> next round / game over. (The problem -> invent -> presenting -> vote
    // chain advances itself via submissions/timers/presenter choices.)
    stopTimer();
    if (state.phase === 'creatorReveal') {
      state.phase = 'leaderboard';
    } else if (state.phase === 'leaderboard') {
      if (state.round < state.settings.rounds) {
        state.round++;
        state.problems = {}; state.assignments = {}; state.inventions = {};
        state.revealOrder = []; state.presentation = null; state.votes = {}; state.roundPoints = {};
        assignMadlibTemplatesIfNeeded();
        state.phase = 'problem';
        startPhaseTimer(currentProblemPhaseTimerSec(), onProblemTimeExpire);
      } else {
        state.phase = 'gameover';
      }
    }
    pushStateToAll();
  }

  function hostKick(peerId) {
    var p = state.players.filter(function (p) { return p.id === peerId; })[0];
    if (p) p.connected = false;
    Net.kick(peerId);
    pushStateToAll();
  }

  function hostHandlePeerLeave(peerId) {
    var p = state.players.filter(function (p) { return p.id === peerId; })[0];
    if (p) p.connected = false;
    // If everyone remaining has submitted for the current phase, let the game proceed.
    if (state.phase === 'problem') checkAllProblemsIn();
    if (state.phase === 'invent') checkAllInventionsIn();
    if (state.phase === 'vote') checkAllVotesIn();
    pushStateToAll();
  }

  function hostHandlePeerJoin(peerId) {
    // JOIN message itself does the real work; nothing else needed here.
  }

  // ---------- Build the personalized view sent to each player ----------
  function buildViewFor(playerId) {
    var v = {
      phase: state.phase,
      round: state.round,
      totalRounds: state.settings.rounds,
      hostId: state.hostId,
      players: state.players.map(function (p) {
        return { id: p.id, name: p.name, color: p.color, score: p.score, connected: p.connected };
      }),
      settings: {
        rounds: state.settings.rounds,
        problemTimeSec: state.settings.problemTimeSec,
        inventionTimeSec: state.settings.inventionTimeSec,
        presentationTimeSec: state.settings.presentationTimeSec,
        votingTimeSec: state.settings.votingTimeSec,
        gameMode: state.settings.gameMode,
        wordTimerSec: state.settings.wordTimerSec,
        numPrompts: state.settings.numPrompts,
        autoRevealSpeed: state.settings.autoRevealSpeed
      },
      settingsLocked: state.phase !== 'lobby',
      timer: state.timer ? { remaining: state.timer.remaining, total: state.timer.total } : null
    };

    if (state.phase === 'problem') {
      v.iSubmittedProblem = !!state.problems[playerId];
      v.submittedCount = Object.keys(state.problems).length;
      v.totalCount = connectedPlayers().length;
      if (state.settings.gameMode !== 'classic') {
        v.madlib = state.madlibAssignments[playerId] || null;
      }
      v.myAssembledProblem = state.problems[playerId] || null;
    }

    if (state.phase === 'invent') {
      var creatorId = state.assignments[playerId];
      v.myProblem = creatorId ? state.problems[creatorId] : null;
      v.iSubmittedInvention = !!state.inventions[playerId];
      v.submittedCount = Object.keys(state.inventions).length;
      v.totalCount = connectedPlayers().length;
    }

    if (state.phase === 'presenting' && state.presentation) {
      var pres = state.presentation;
      var currentId = state.revealOrder[pres.index];
      var inv = state.inventions[currentId] || {};
      v.presentation = {
        mode: pres.mode, // null until the presenter picks AUTO/MANUAL
        index: pres.index,
        total: state.revealOrder.length,
        revealed: pres.revealed,
        justRevealed: pres.lastRevealedField,
        isPresenter: playerId === pres.presenterId,
        invention: {
          drawing: pres.revealed.drawing ? inv.drawing : null,
          product: pres.revealed.product ? inv.product : null,
          name: pres.revealed.name ? inv.name : null,
          slogan: pres.revealed.slogan ? inv.slogan : null,
          price: pres.revealed.price ? inv.price : null
        }
      };
    }

    if (state.phase === 'vote') {
      v.gallery = state.revealOrder.map(function (pid) {
        var inv = state.inventions[pid] || {};
        return { drawing: inv.drawing, product: inv.product, name: inv.name, slogan: inv.slogan, price: inv.price };
      });
      v.mySubmissionIndex = state.revealOrder.indexOf(playerId);
      v.iVoted = state.votes[playerId] !== undefined;
      v.votedCount = Object.keys(state.votes).length;
      v.totalCount = connectedPlayers().length;
    }

    if (state.phase === 'creatorReveal' || state.phase === 'leaderboard' || state.phase === 'gameover') {
      v.gallery = state.revealOrder.map(function (pid) {
        var inv = state.inventions[pid] || {};
        var creator = state.players.filter(function (p) { return p.id === pid; })[0];
        return {
          drawing: inv.drawing, product: inv.product, name: inv.name, slogan: inv.slogan, price: inv.price,
          creatorName: creator ? creator.name : '?', creatorColor: creator ? creator.color : '#888',
          votes: state.roundPoints ? (state.roundPoints[pid] || 0) : 0
        };
      });
      v.leaderboard = state.players.slice().sort(function (a, b) { return b.score - a.score; })
        .map(function (p) { return { name: p.name, color: p.color, score: p.score }; });
    }

    if (state.phase === 'gameover') {
      var maxScore = Math.max.apply(null, state.players.map(function (p) { return p.score; }));
      var topPlayers = state.players.filter(function (p) { return p.score === maxScore; });
      if (topPlayers.length > 1) {
        var maxVotes = Math.max.apply(null, topPlayers.map(function (p) { return p.totalVotes; }));
        topPlayers = topPlayers.filter(function (p) { return p.totalVotes === maxVotes; });
      }
      v.winners = topPlayers.map(function (p) { return { name: p.name, color: p.color, score: p.score }; });
    }

    return v;
  }

  function pushStateToAll(extra) {
    if (!Net.isHost()) return;
    state.players.forEach(function (p) {
      var view = buildViewFor(p.id);
      if (extra) { for (var k in extra) view[k] = extra[k]; }
      if (p.id === meId) {
        myView = view;
        onUpdate();
      } else if (p.connected) {
        Net.sendTo(p.id, { type: 'STATE', view: view });
      }
    });
  }

  // ---------- CLIENT ----------
  function clientHandleMessage(msg) {
    if (msg.type === 'JOIN_OK') {
      meId = msg.you.id; meName = msg.you.name;
      onUpdate();
    } else if (msg.type === 'JOIN_REJECTED') {
      onUpdate({ joinRejected: msg.reason });
    } else if (msg.type === 'STATE') {
      myView = msg.view;
      onUpdate();
    } else if (msg.type === 'KICKED') {
      onUpdate({ kicked: true });
    }
  }

  function clientSubmitProblem(text) { Net.sendToHost({ type: 'SUBMIT_PROBLEM', text: text }); }
  function clientSubmitInvention(inv) {
    Net.sendToHost({
      type: 'SUBMIT_INVENTION',
      drawing: inv.drawing, product: inv.product, name: inv.name, slogan: inv.slogan, price: inv.price
    });
  }
  function clientSubmitVote(targetIndex) { Net.sendToHost({ type: 'SUBMIT_VOTE', targetIndex: targetIndex }); }
  function clientChoosePresentMode(mode) { Net.sendToHost({ type: 'CHOOSE_PRESENT_MODE', mode: mode }); }
  function clientShowField(field) { Net.sendToHost({ type: 'SHOW_FIELD', field: field }); }
  function clientNextInvention() { Net.sendToHost({ type: 'NEXT_INVENTION' }); }

  return {
    hostInit: hostInit,
    hostHandleMessage: hostHandleMessage,
    hostStartGame: hostStartGame,
    hostAdvance: hostAdvance,
    hostKick: hostKick,
    hostUpdateSetting: hostUpdateSetting,
    hostForceNextInvention: hostForceNextInvention,
    hostHandlePeerLeave: hostHandlePeerLeave,
    hostHandlePeerJoin: hostHandlePeerJoin,
    clientHandleMessage: clientHandleMessage,
    clientSubmitProblem: clientSubmitProblem,
    clientSubmitInvention: clientSubmitInvention,
    clientSubmitVote: clientSubmitVote,
    clientChoosePresentMode: clientChoosePresentMode,
    clientShowField: clientShowField,
    clientNextInvention: clientNextInvention,
    setOnUpdate: setOnUpdate,
    getView: function () { return myView; },
    getMeId: function () { return meId; },
    getMeName: function () { return meName; }
  };
})();
