// ui.js — pure rendering. Reads App/Game state and writes HTML into #app.
// Interactive elements call back into global App.* functions (see main.js).
//
// IMPORTANT: full re-renders (mount()) replace the whole screen, which would
// wipe out anything the player is mid-typing/mid-drawing (a textarea, the
// invention form, the canvas, a Mad Libs blank). main.js is responsible for
// NOT calling a full render() on every timer tick — see updateTimer() below,
// which patches just the countdown in place so the rest of the screen (and
// its DOM state) is left completely alone. Mad Libs Live's sentence preview
// is similarly patched in place on each keystroke (see madlibLiveInput)
// rather than going through a full re-render.

var UI = (function () {
  var root;
  function init(rootEl) { root = rootEl; }

  // Full screen replace, with a quick fade/rise-in so phase transitions feel
  // intentional rather than an abrupt content swap. `wide` widens the outer
  // container for screens that need real two-column layout space (Invent,
  // Presentation) — every other screen stays at the normal, narrower width.
  function mount(html, wide) {
    root.innerHTML = html;
    root.classList.toggle('app-wide', !!wide);
    root.classList.remove('screen-enter');
    void root.offsetWidth; // force reflow so the animation restarts every time
    root.classList.add('screen-enter');
  }

  function esc(s) {
    return (s || '').replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function brand() {
    return '<div class="brand"><div class="logo">Problem <span>Child</span></div><div class="tag">an invention party game</div></div>';
  }

  function playerChip(p, opts) {
    opts = opts || {};
    return '<div class="player-chip ' + (p.connected === false ? 'offline' : '') + '">' +
      '<div class="dot" style="background:' + p.color + '"></div>' +
      '<div class="name">' + esc(p.name) + (p.connected === false ? ' <span class="muted small">(disconnected)</span>' : '') + '</div>' +
      (opts.isHost ? '<div class="host-badge">HOST</div>' : '') +
      (opts.showScore ? '<div class="score">' + p.score + ' pts</div>' : '') +
      '</div>';
  }

  // ---------------- LANDING ----------------
  function renderLanding(errorMsg) {
    mount(brand() +
      (errorMsg ? '<div class="status-banner warn">' + esc(errorMsg) + '</div>' : '') +
      '<div class="card">' +
      '<h2 class="center" style="margin-top:0;">Create or Join</h2>' +
      '<p class="muted center small">2–8 players. Everyone opens their own copy of this file, and connects to the same game over the internet — no installs, no accounts.</p>' +
      '<label>Your name</label>' +
      '<input type="text" id="nameInput" maxlength="18" placeholder="e.g. Sam">' +
      '<div class="row" style="margin-top:18px;">' +
      '<button class="btn block" onclick="App.createGame()">Create Game</button>' +
      '</div>' +
      '<div class="row" style="margin-top:10px;align-items:center;">' +
      '<input type="text" id="codeInput" maxlength="4" placeholder="GAME CODE" style="text-transform:uppercase;letter-spacing:3px;font-weight:700;">' +
      '<button class="btn secondary" style="flex:0 0 auto;" onclick="App.joinGame()">Join</button>' +
      '</div>' +
      '</div>' +
      '<p class="footer-note">The player who clicks Create Game must keep this tab open for the whole session — everyone else connects through them.</p>');
  }

  function renderConnecting(text) {
    mount(brand() + '<div class="card center"><p class="waiting-dots">' + esc(text) + '</p></div>');
  }

  // ---------------- LOBBY ----------------
  function renderLobby(view, isHost, meId) {
    var players = view.players;
    var html = brand();
    html += '<div class="card center">' +
      '<div class="muted small">GAME CODE</div>' +
      '<div class="code-display" id="roomCode">' + (window.__roomCode || '') + '</div>' +
      '<button class="btn secondary sm" onclick="App.copyCode()">Copy code</button>' +
      '</div>';
    html += '<div class="card">' +
      '<div class="phase-header"><div class="eyebrow">Lobby</div><h2>' + players.length + ' / 8 players</h2></div>';
    players.forEach(function (p) {
      html += playerChip(p, { isHost: p.id === view.hostId });
    });
    html += '</div>';

    if (isHost) {
      html += '<div class="card">' +
        '<p class="muted small" style="margin-top:0;">Game mode, rounds, and timers are set from the Settings icon in the corner.</p>' +
        '<button class="btn block" ' + (players.length < 2 ? 'disabled' : '') + ' onclick="App.hostStart()">' +
        (players.length < 2 ? 'Need at least 2 players' : 'Start Game') + '</button>' +
        '</div>';
    } else {
      html += '<div class="status-banner">Waiting for the host to start the game<span class="waiting-dots"></span></div>';
    }
    mount(html);
  }

  // ---------------- TIMER BADGE ----------------
  var TIMER_LABELS = { problem: 'TIME LEFT', invent: 'INVENTION TIME', vote: 'VOTING TIME', presenting: 'PRESENTATION TIME' };
  function timerBadge(view) {
    if (!view.timer) return '';
    var m = Math.floor(view.timer.remaining / 60);
    var s = view.timer.remaining % 60;
    var label = view.phase === 'problem'
      ? (view.settings.gameMode === 'classic' ? 'PROBLEM TIME' : 'WORD TIMER')
      : (TIMER_LABELS[view.phase] || 'TIME LEFT');
    var urgent = view.timer.remaining <= 10;
    return '<div class="timer-badge' + (urgent ? ' urgent' : '') + '" id="timerBadge">' +
      '<div class="timer-badge-label">' + label + '</div>' +
      '<div class="timer-badge-value" id="timerBadgeValue">' + m + ':' + (s < 10 ? '0' : '') + s + '</div>' +
      '</div>';
  }

  // Patches ONLY the countdown text in place — does not touch anything else
  // on screen. This is what lets a timer keep ticking while someone is
  // mid-sentence in the problem textarea, mid-stroke on the canvas, or
  // mid-blank in a Mad Libs form.
  function updateTimer(view) {
    var badge = document.getElementById('timerBadge');
    var valueEl = document.getElementById('timerBadgeValue');
    if (!badge || !valueEl) return;
    if (!view.timer) { badge.style.display = 'none'; return; }
    badge.style.display = '';
    var m = Math.floor(view.timer.remaining / 60);
    var s = view.timer.remaining % 60;
    valueEl.textContent = m + ':' + (s < 10 ? '0' : '') + s;
    badge.classList.toggle('urgent', view.timer.remaining <= 10);
  }

  // ---------------- PROBLEM PHASE ----------------
  var ML_LABELS = { noun: 'a noun', verb: 'a verb (any form)', adjective: 'an adjective', place: 'a place', animal: 'an animal', food: 'a food' };

  function renderProblem(view, madlib) {
    var html = brand();
    html += timerBadge(view);
    html += '<div class="phase-header"><div class="eyebrow">Round ' + view.round + ' of ' + view.totalRounds + '</div><h2>Give someone a problem</h2></div>';

    if (view.iSubmittedProblem) {
      html += '<div class="card center"><p>Your problem is locked in.</p>';
      if (view.myAssembledProblem) {
        html += '<p class="problem-reveal">&ldquo;' + esc(view.myAssembledProblem) + '&rdquo;</p>';
      }
      html += '<p class="muted small">Waiting on ' + (view.totalCount - view.submittedCount) + ' more player(s)<span class="waiting-dots"></span></p></div>';
      mount(html);
      return;
    }

    if (view.settings.gameMode === 'classic') {
      html += '<div class="card">' +
        '<p class="muted small">Write a funny, ridiculous, or real problem. Someone else will have to invent a solution for it — they won\'t know it came from you.</p>' +
        '<textarea id="problemInput" maxlength="220" placeholder="e.g. How do we stop the dog from eating the mail?"></textarea>' +
        '<button class="btn block" style="margin-top:14px;" onclick="App.submitProblem()">Submit Problem</button>' +
        '</div>';
      mount(html);
      return;
    }

    if (!madlib || !madlib.template) {
      html += '<div class="card center"><p class="waiting-dots">Preparing your prompt</p></div>';
      mount(html);
      return;
    }

    if (view.settings.gameMode === 'madlibs_blind') html += renderMadlibBlind(madlib);
    else html += renderMadlibLive(madlib);
    mount(html);
    if (view.settings.gameMode === 'madlibs_live') wireLiveInputs();
  }

  function renderMadlibBlind(madlib) {
    var t = madlib.template;
    if (madlib.index >= t.blanks.length) {
      var assembled = assembleMadlib(t, madlib.answers);
      return '<div class="card center">' +
        '<div class="muted small">Your problem</div>' +
        '<p class="problem-reveal" style="margin:10px 0 18px;">&ldquo;' + esc(assembled) + '&rdquo;</p>' +
        '<button class="btn block" onclick="App.madlibSubmit()">Submit Problem</button>' +
        '</div>';
    }
    var type = t.blanks[madlib.index];
    return '<div class="card">' +
      '<div class="muted small">Prompt ' + (madlib.index + 1) + ' of ' + t.blanks.length + '</div>' +
      '<h2 style="margin:8px 0 16px;">Give me ' + (ML_LABELS[type] || type) + '</h2>' +
      '<input type="text" id="mlBlindInput" maxlength="24" placeholder="Type your answer" autocomplete="off">' +
      '<button class="btn block" style="margin-top:14px;" onclick="App.madlibBlindNext()">' +
      (madlib.index === t.blanks.length - 1 ? 'Reveal My Problem' : 'Next') + '</button>' +
      '</div>';
  }

  function renderMadlibLive(madlib) {
    var t = madlib.template;
    var html = '<div class="card">' +
      '<p class="muted small" style="margin-top:0;">Fill in the blanks — watch the sentence build as you go.</p>' +
      '<div class="ml-preview">' + buildLivePreviewHTML(t) + '</div>' +
      '<div class="ml-inputs">';
    t.blanks.forEach(function (type, i) {
      html += '<label>' + capitalize(ML_LABELS[type] || type) + '</label>' +
        '<input type="text" maxlength="24" autocomplete="off" data-mlblank="' + i + '" data-type="' + type + '" oninput="App.madlibLiveInput(' + i + ', this.value)">';
    });
    html += '</div>' +
      '<button class="btn block" style="margin-top:16px;" onclick="App.madlibSubmit()">Submit Problem</button>' +
      '</div>';
    return html;
  }

  function buildLivePreviewHTML(template) {
    var text = template.text;
    for (var i = 0; i < template.blanks.length; i++) {
      var type = template.blanks[i];
      var chip = '<span class="ml-blank" id="mlBlank' + i + '" data-type="' + type + '">[ ' + esc(ML_LABELS[type] || type) + ' ]</span>';
      text = text.split('{' + i + '}').join(chip);
    }
    return text;
  }

  function wireLiveInputs() {
    // Restore any values already typed before a background re-render happened
    // (shouldn't normally occur, since madlibLiveInput never triggers one, but
    // this keeps the preview correct if the screen is ever rebuilt anyway).
  }

  function assembleMadlib(template, answers) {
    var text = template.text;
    for (var i = 0; i < template.blanks.length; i++) {
      var val = (answers[i] || '').trim() || '(blank)';
      text = text.split('{' + i + '}').join(val);
    }
    return text;
  }

  // Called directly from main.js on every Mad Libs Live keystroke — patches
  // just that one blank's preview chip, no full re-render, no lost focus.
  function madlibLivePatch(index, value, type) {
    var el = document.getElementById('mlBlank' + index);
    if (!el) return;
    var trimmed = value.trim();
    el.textContent = trimmed ? trimmed : '[ ' + (ML_LABELS[type] || type) + ' ]';
    el.classList.toggle('filled', !!trimmed);
  }

  function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }

  // ---------------- COMPACT TIMER CHIP (for the new headers) ----------------
  // Same #timerBadge/#timerBadgeValue ids as timerBadge() above, so
  // updateTimer()'s in-place patch works identically regardless of which
  // variant is on screen.
  function timerChip(view) {
    if (!view.timer) return '';
    var m = Math.floor(view.timer.remaining / 60);
    var s = view.timer.remaining % 60;
    var urgent = view.timer.remaining <= 10;
    return '<div class="timer-chip' + (urgent ? ' urgent' : '') + '" id="timerBadge">' +
      Icons.clock() + '<span id="timerBadgeValue">' + m + ':' + (s < 10 ? '0' : '') + s + '</span>' +
      '</div>';
  }

  // ---------------- INVENT PHASE ----------------
  function renderInvent(view) {
    var html = brand();
    html += '<div class="invent-header">' +
      '<div><div class="section-eyebrow">Round ' + view.round + ' / ' + view.totalRounds + '</div>' +
      '<h2 class="section-title">Design Your Invention</h2></div>' +
      timerChip(view) +
      '</div>';

    if (view.iSubmittedInvention) {
      html += '<div class="card center"><p>Your invention is submitted.</p><p class="muted small">Waiting on ' + (view.totalCount - view.submittedCount) + ' more player(s)<span class="waiting-dots"></span></p></div>';
      mount(html);
      return;
    }

    html += '<div class="problem-card"><div class="problem-card-label">Your Problem</div>' +
      '<div class="problem-card-text">' + esc(view.myProblem || '') + '</div></div>';

    html += '<div class="invent-layout">';

    // Left: drawing + toolbar
    html += '<div class="invent-canvas-col">' +
      '<div class="invent-col-label">Draw Your Invention</div>' +
      '<div class="canvas-wrap"><canvas id="drawCanvas" width="640" height="480"></canvas></div>' +
      '<div class="draw-toolbar">' +
      '<div class="toolbar-group">' +
      '<span class="toolbar-group-label">Tools</span>' +
      '<button class="tool-btn" id="toolPen" title="Pen" onclick="App.setTool(\'pen\')">' + Icons.pen() + ' Pen</button>' +
      '<button class="tool-btn" id="toolEraser" title="Eraser" onclick="App.setTool(\'eraser\')">' + Icons.eraser() + ' Eraser</button>' +
      '</div>' +
      '<div class="toolbar-divider"></div>' +
      '<div class="toolbar-group">' +
      '<span class="toolbar-group-label">Brush</span>' +
      '<input type="color" id="colorPicker" value="#1a1a1a" title="Color" onchange="App.setColor(this.value)">' +
      '<div class="brush-size-control" title="Brush size">' +
      '<button type="button" class="brush-btn" onclick="App.adjustBrushSize(-2)">&minus;</button>' +
      '<input type="range" min="2" max="26" value="6" id="sizeSlider" oninput="App.setSize(this.value)">' +
      '<button type="button" class="brush-btn" onclick="App.adjustBrushSize(2)">+</button>' +
      '<span class="brush-size-value" id="brushSizeValue">6</span>' +
      '</div></div>' +
      '<div class="toolbar-divider"></div>' +
      '<div class="toolbar-group">' +
      '<span class="toolbar-group-label">Edit</span>' +
      '<button class="tool-btn" title="Undo" onclick="App.undo()">' + Icons.undo() + ' Undo</button>' +
      '<button class="tool-btn" title="Redo" onclick="App.redo()">' + Icons.redo() + ' Redo</button>' +
      '<button class="tool-btn" title="Clear canvas (asks first)" onclick="App.clearCanvas()">' + Icons.trash() + ' Clear</button>' +
      '</div>' +
      '</div></div>';

    // Right: invention info card
    html += '<div class="invent-info-col"><div class="invent-info-card">' +
      '<div class="invent-col-label">Your Invention</div>' +
      '<div class="invent-progress"><span class="invent-progress-dots">' +
      ['product', 'name', 'slogan', 'price'].map(function (f) { return '<span class="progress-dot" data-field="' + f + '"></span>'; }).join('') +
      '</span><span class="invent-progress-count" id="inventProgressCount">0 / 4 complete</span></div>' +
      '<label>Product</label><input type="text" id="invProduct" maxlength="80" placeholder="What is your invention?" oninput="App.onInventFieldInput(\'invProduct\')">' +
      '<label>Name</label><input type="text" id="invName" maxlength="60" placeholder="What\'s it called?" oninput="App.onInventFieldInput(\'invName\')">' +
      '<label>Slogan</label><input type="text" id="invSlogan" maxlength="100" placeholder="Give it a catchy tagline..." oninput="App.onInventFieldInput(\'invSlogan\')">' +
      '<label>Price</label><div class="price-input-wrap"><span class="price-prefix">$</span>' +
      '<input type="text" id="invPrice" maxlength="30" placeholder="9,999" oninput="App.onInventFieldInput(\'invPrice\')"></div>' +
      '<div class="invent-submit-error" id="inventSubmitError"></div>' +
      '<button class="btn block invent-submit-btn" onclick="App.submitInvention()">Submit Invention</button>' +
      '</div></div>';

    html += '</div>'; // .invent-layout

    mount(html, true);

    Drawing.init(document.getElementById('drawCanvas'));
    document.getElementById('toolPen').classList.add('active');
  }

  // ---------------- PRESENTATION ----------------
  var PRESENT_FIELD_LABELS = { drawing: 'DRAWING', product: 'PRODUCT', name: 'NAME', slogan: 'SLOGAN', price: 'PRICE' };

  function renderPresenting(view, isHost) {
    var p = view.presentation;
    var html = brand();
    html += '<div class="present-header">' +
      '<div><div class="section-eyebrow">Presentation ' + (p.index + 1) + ' / ' + p.total + '</div>' +
      '<h2 class="section-title">Invention Presentation</h2></div>' +
      timerChip(view) +
      '</div>';

    if (!p.mode) {
      if (p.isPresenter) {
        html += '<div class="card center">' +
          '<h2 style="margin-top:0;">Choose how you want to present</h2>' +
          '<p class="muted small">Nobody else knows this is your invention yet.</p>' +
          '<div class="row" style="margin-top:14px;">' +
          '<button class="btn block" onclick="App.presenterChooseMode(\'auto\')">AUTO<div class="mode-sub">Reveals itself, paced automatically</div></button>' +
          '<button class="btn secondary block" onclick="App.presenterChooseMode(\'manual\')">MANUAL<div class="mode-sub">You control the reveal order</div></button>' +
          '</div></div>';
      } else {
        html += '<div class="status-banner">Waiting for the next presenter to choose a style<span class="waiting-dots"></span></div>';
      }
      if (isHost) html += skipLinkHTML();
      mount(html);
      return;
    }

    var inv = p.invention;
    html += '<div class="present-layout">';

    html += '<div class="present-drawing-col">' +
      '<div class="present-col-label">The Invention</div>' +
      '<div class="present-drawing-frame' + (p.justRevealed === 'drawing' ? ' pop' : '') + '">' +
      (inv.drawing ? '<img src="' + inv.drawing + '">' : '<div class="stage-placeholder">🎨<span>Get ready&hellip;</span></div>') +
      '</div></div>';

    html += '<div class="present-info-col"><div class="present-info-card">';
    html += presentInfoRow('PRODUCT', inv.product, p.justRevealed === 'product');
    html += presentInfoRow('NAME', inv.name, p.justRevealed === 'name');
    html += presentInfoRow('SLOGAN', inv.slogan ? '"' + esc(inv.slogan) + '"' : null, p.justRevealed === 'slogan', true);
    html += presentInfoRow('PRICE', inv.price, p.justRevealed === 'price');
    html += '</div></div>';

    html += '</div>'; // .present-layout

    var fields = ['drawing', 'product', 'name', 'slogan', 'price'];
    var allDone = fields.every(function (f) { return p.revealed[f]; });
    var canClick = p.mode === 'manual' && p.isPresenter;

    html += '<div class="present-controls-bar">';
    html += '<div class="present-check-row">';
    fields.forEach(function (f) {
      var shown = p.revealed[f];
      var clickable = canClick && !shown;
      html += '<button class="present-check-item' + (shown ? ' done' : '') + '" ' +
        (clickable ? 'onclick="App.presenterShowField(\'' + f + '\')"' : 'disabled') + '>' +
        (shown ? Icons.check() + ' ' : '') + PRESENT_FIELD_LABELS[f] + '</button>';
    });
    html += '</div>';

    if (allDone) {
      html += '<div class="present-complete">' + Icons.check() + ' PRESENTATION COMPLETE</div>';
      if (canClick) {
        html += '<button class="btn present-next-btn" onclick="App.presenterNextInvention()">Next Invention &rarr;</button>';
      } else if (p.mode === 'auto') {
        html += '<div class="status-banner small">Moving to the next invention<span class="waiting-dots"></span></div>';
      } else {
        html += '<div class="status-banner small">Waiting for the presenter to continue<span class="waiting-dots"></span></div>';
      }
    } else if (p.mode === 'auto') {
      html += '<div class="status-banner small">Revealing automatically<span class="waiting-dots"></span></div>';
    } else if (!p.isPresenter) {
      html += '<div class="status-banner small">Someone is presenting their invention<span class="waiting-dots"></span></div>';
    } else {
      html += '<p class="muted small center" style="margin:0;">YOU ARE PRESENTING — tap a piece above to reveal it, in any order.</p>';
    }
    html += '</div>'; // .present-controls-bar

    if (isHost) html += skipLinkHTML();
    mount(html, true);
  }

  function presentInfoRow(label, value, justRevealed, italic) {
    if (value === null || value === undefined) {
      return '<div class="present-info-row placeholder"><div class="present-info-label">' + label + '</div><div class="present-info-value dim">&mdash;</div></div>';
    }
    return '<div class="present-info-row' + (justRevealed ? ' pop current' : '') + '">' +
      '<div class="present-info-label">' + label + '</div>' +
      '<div class="present-info-value' + (italic ? ' italic' : '') + '">' + (italic ? value : esc(value)) + '</div>' +
      '</div>';
  }

  function skipLinkHTML() {
    return '<p class="center" style="margin-top:16px;"><a href="#" class="host-skip-link" onclick="App.hostForceNext();return false;">Host: skip to next invention</a></p>';
  }

  function inventionCardHTML(inv, num, extra) {
    extra = extra || '';
    return '<div class="invention-card">' +
      (inv.drawing ? '<img src="' + inv.drawing + '">' : '') +
      '<div class="body">' +
      '<div class="muted small">INVENTION #' + num + '</div>' +
      '<div class="name">' + esc(inv.name) + '</div>' +
      '<div class="slogan">"' + esc(inv.slogan) + '"</div>' +
      '<div class="meta"><span>' + esc(inv.product) + '</span><span class="price-tag">' + esc(inv.price) + '</span></div>' +
      extra +
      '</div></div>';
  }

  // ---------------- VOTE ----------------
  function renderVote(view) {
    var html = brand();
    html += timerBadge(view);
    html += '<div class="phase-header"><div class="eyebrow">Round ' + view.round + '</div><h2>Vote for your favorite</h2></div>';
    if (view.iVoted) {
      html += '<div class="card center"><p>Vote submitted!</p><p class="muted small">Waiting on ' + (view.totalCount - view.votedCount) + ' more vote(s)<span class="waiting-dots"></span></p></div>';
      mount(html);
      return;
    }
    html += '<p class="muted small">You can\'t vote for your own invention — it\'s marked below.</p>';
    view.gallery.forEach(function (inv, i) {
      var isMine = i === view.mySubmissionIndex;
      var btn = isMine
        ? '<button class="btn secondary sm block" style="margin-top:10px;" disabled>This one is yours</button>'
        : '<button class="btn sm block" style="margin-top:10px;" onclick="App.submitVote(' + i + ')">Vote for this</button>';
      html += inventionCardHTML(inv, i + 1, btn);
    });
    mount(html);
  }

  // ---------------- CREATOR REVEAL ----------------
  function renderCreatorReveal(view, isHost) {
    var html = brand();
    html += '<div class="phase-header"><div class="eyebrow">Round ' + view.round + '</div><h2>Who made what</h2></div>';
    view.gallery.forEach(function (inv, i) {
      var extra = '<div class="creator"><div class="dot" style="background:' + inv.creatorColor + '"></div>' + esc(inv.creatorName) + '</div>' +
        '<div class="meta" style="margin-top:6px;"><span>Votes</span><span class="votes">' + inv.votes + '</span></div>';
      html += inventionCardHTML(inv, i + 1, extra);
    });
    if (isHost) html += '<button class="btn block" onclick="App.hostAdvance()">See Leaderboard →</button>';
    else html += '<div class="status-banner">Waiting for the host to continue<span class="waiting-dots"></span></div>';
    mount(html);
  }

  // ---------------- LEADERBOARD ----------------
  function renderLeaderboard(view, isHost) {
    var html = brand();
    html += '<div class="phase-header"><div class="eyebrow">After round ' + view.round + ' of ' + view.totalRounds + '</div><h2>Leaderboard</h2></div>';
    html += '<div class="card">';
    view.leaderboard.forEach(function (p, i) {
      html += '<div class="leaderboard-row"><div class="rank">#' + (i + 1) + '</div>' +
        '<div class="dot" style="background:' + p.color + '"></div>' +
        '<div>' + esc(p.name) + '</div><div class="pts">' + p.score + ' pts</div></div>';
    });
    html += '</div>';
    var isLast = view.round >= view.totalRounds;
    if (isHost) html += '<button class="btn block" onclick="App.hostAdvance()">' + (isLast ? 'See Final Results →' : 'Next Round →') + '</button>';
    else html += '<div class="status-banner">Waiting for the host to continue<span class="waiting-dots"></span></div>';
    mount(html);
  }

  // ---------------- GAME OVER ----------------
  function renderGameOver(view) {
    var html = brand();
    var winners = view.winners;
    html += '<div class="card winner-hero">' +
      '<div class="trophy">🏆</div>' +
      winners.map(function (w) {
        return '<div class="wname" style="color:' + w.color + '">' + esc(w.name) + '</div>';
      }).join(winners.length > 1 ? '<div class="muted">tied with</div>' : '') +
      '<div class="wpts">' + winners[0].score + ' points' + (winners.length > 1 ? ' each' : '') + '</div>' +
      '</div>';
    html += '<div class="card"><h3 style="margin-top:0;">Final Leaderboard</h3>';
    view.leaderboard.forEach(function (p, i) {
      html += '<div class="leaderboard-row"><div class="rank">#' + (i + 1) + '</div>' +
        '<div class="dot" style="background:' + p.color + '"></div>' +
        '<div>' + esc(p.name) + '</div><div class="pts">' + p.score + ' pts</div></div>';
    });
    html += '</div>';
    html += '<div class="card"><h3 style="margin-top:0;">Every invention this game</h3>';
    view.gallery.forEach(function (inv, i) {
      var extra = '<div class="creator"><div class="dot" style="background:' + inv.creatorColor + '"></div>' + esc(inv.creatorName) + '</div>';
      html += inventionCardHTML(inv, i + 1, extra);
    });
    html += '</div>';
    html += '<p class="footer-note">Refresh both the host and player tabs to start a brand new game.</p>';
    mount(html);
  }

  return {
    init: init,
    renderLanding: renderLanding,
    renderConnecting: renderConnecting,
    renderLobby: renderLobby,
    renderProblem: renderProblem,
    renderInvent: renderInvent,
    renderPresenting: renderPresenting,
    renderVote: renderVote,
    renderCreatorReveal: renderCreatorReveal,
    renderLeaderboard: renderLeaderboard,
    renderGameOver: renderGameOver,
    updateTimer: updateTimer,
    assembleMadlib: assembleMadlib,
    madlibLivePatch: madlibLivePatch
  };
})();
