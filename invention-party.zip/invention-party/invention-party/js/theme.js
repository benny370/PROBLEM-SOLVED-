// theme.js — the theme system: six named color themes (each its own
// primary/secondary pair), a dark/light shade, and a per-theme
// primary/secondary swap. Personal, per-device preference — saved to
// localStorage, never synced through the multiplayer game state (each
// player can look completely different from everyone else).
//
// Loaded as the very first thing in <head> and runs immediately (not
// waiting for DOMContentLoaded) so the correct palette is already applied
// before the page's first paint — no flash of the wrong colors/theme.
//
// HOW A THEME BECOMES A FULL PALETTE: each theme only specifies two colors
// (primary/secondary). Backgrounds/surfaces/borders/text are derived from
// the primary color's hue via HSL math, tinting the whole UI toward that
// theme's identity rather than using one universal gray. The secondary
// color becomes the main highlight (buttons, timers, prices); the primary
// becomes the structural color (borders, secondary buttons). The swap
// button flips which raw color fills which role.

var Theme = (function () {
  var THEMES = {
    electric: { name: 'Electric', primary: '#C700AA', secondary: '#F9D372' },
    workshop: { name: 'Workshop', primary: '#168BFF', secondary: '#FF8A24' },
    garden: { name: 'Garden', primary: '#35C46A', secondary: '#F3E6C8' },
    arcade: { name: 'Arcade', primary: '#FF4057', secondary: '#20D9E8' },
    pop: { name: 'Pop', primary: '#FF4FA3', secondary: '#7B61A8' },
    classic_workshop: { name: 'Classic Workshop', primary: '#A66A3F', secondary: '#F4C95D' },
    seafoam: { name: 'Seafoam', primary: '#71D9C3', secondary: '#FF7F6E' },
    safari: { name: 'Safari', primary: '#667A32', secondary: '#FF7A00' },
    tech: { name: 'Tech', primary: '#25282B', secondary: '#B6FF00' },
    monochrome: { name: 'Monochrome', primary: '#F2F2F2', secondary: '#777777' }
  };
  // Electric listed first as a nod to the original scheme; Workshop is the
  // actual default the first time someone opens the game (see below).
  var THEME_ORDER = [
    'electric', 'workshop', 'garden', 'arcade', 'pop', 'classic_workshop',
    'seafoam', 'safari', 'tech', 'monochrome'
  ];

  var shade = 'dark';
  var colorTheme = 'workshop';
  var swaps = {}; // themeKey -> bool, remembered independently per theme

  load();

  function load() {
    try {
      var s = localStorage.getItem('themeMode');
      if (s === 'light' || s === 'dark') shade = s;
    } catch (e) { /* localStorage unavailable — defaults stand */ }
    try {
      var ct = localStorage.getItem('colorTheme');
      if (ct && THEMES[ct]) colorTheme = ct;
    } catch (e) {}
    try {
      var sw = localStorage.getItem('colorThemeSwaps');
      if (sw) swaps = JSON.parse(sw) || {};
    } catch (e) {}
  }

  function save() {
    try { localStorage.setItem('themeMode', shade); } catch (e) {}
    try { localStorage.setItem('colorTheme', colorTheme); } catch (e) {}
    try { localStorage.setItem('colorThemeSwaps', JSON.stringify(swaps)); } catch (e) {}
  }

  // ---------------- color math ----------------
  function hexToHsl(hex) {
    hex = hex.replace('#', '');
    var r = parseInt(hex.substr(0, 2), 16) / 255;
    var g = parseInt(hex.substr(2, 2), 16) / 255;
    var b = parseInt(hex.substr(4, 2), 16) / 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b);
    var h, s, l = (max + min) / 2;
    if (max === min) { h = s = 0; }
    else {
      var d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return { h: h, s: s * 100, l: l * 100 };
  }

  function hslToHex(h, s, l) {
    s /= 100; l /= 100;
    var c = (1 - Math.abs(2 * l - 1)) * s;
    var x = c * (1 - Math.abs((h / 60) % 2 - 1));
    var m = l - c / 2;
    var r, g, b;
    if (h < 60) { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    function toHex(v) { var n = Math.round((v + m) * 255); var s2 = n.toString(16); return s2.length < 2 ? '0' + s2 : s2; }
    return '#' + toHex(r) + toHex(g) + toHex(b);
  }

  // Pastel/cream-like colors (e.g. Garden's cream secondary) are left
  // completely alone regardless of mode — darkening a cream just turns it
  // into mud, so it's used as-is in both dark and light. Used for the
  // --accent (highlight) slot only.
  function adjustAccent(hex, forShade) {
    var hsl = hexToHsl(hex);
    if (hsl.l > 78) return hex;
    if (forShade === 'light' && hsl.l > 55) return hslToHex(hsl.h, Math.min(hsl.s, 85), 42);
    if (forShade === 'dark' && hsl.l < 35) return hslToHex(hsl.h, Math.min(hsl.s, 85), 62);
    // Near-gray colors (e.g. Monochrome's mid-gray) paired with the fixed
    // near-black button text need a bit more lightness for reliable
    // contrast, in either shade. Saturated theme colors never hit this —
    // it only fires below 12% saturation, which none of the original six
    // themes' colors have.
    if (hsl.s < 12 && hsl.l < 58) return hslToHex(hsl.h, hsl.s, 62);
    return hex;
  }

  // Same idea, but for the --accent-purple (structural/border) slot, which
  // always needs to contrast against its surface in BOTH shades — a border
  // has no "let it stay pale" exception the way a highlight color does. This
  // is identical to adjustAccent minus the l>78 skip; since none of the
  // original six themes' primaries exceed l=78, removing that skip changes
  // nothing for them — it only matters for Monochrome's near-white primary,
  // which needs to darken for use as a border against a light background.
  function adjustStructural(hex, forShade) {
    var hsl = hexToHsl(hex);
    if (forShade === 'light' && hsl.l > 55) return hslToHex(hsl.h, Math.min(hsl.s, 85), 42);
    if (forShade === 'dark' && hsl.l < 35) return hslToHex(hsl.h, Math.min(hsl.s, 85), 62);
    return hex;
  }

  // Backgrounds/surfaces/borders/text are synthesized from the structural
  // color's hue — this is what gives each theme its own tinted "world"
  // rather than one universal gray dark-mode. Achromatic sources (e.g.
  // Monochrome's near-white, Tech's near-neutral charcoal) are detected and
  // kept genuinely gray instead of being tinted toward a meaningless hue —
  // without this, a perfectly neutral gray (hue mathematically undefined,
  // read as 0/red) would produce a reddish-tinted "Monochrome" background,
  // which defeats the point of the theme.
  function derivePalette(structuralHex, forShade) {
    var hsl = hexToHsl(structuralHex);
    var h = hsl.h;
    var neutral = hsl.s < 12;
    var sA = neutral ? 0 : 45, sB = neutral ? 0 : 32, sC = neutral ? 0 : 30, sD = neutral ? 0 : 28, sE = neutral ? 0 : 12, sF = neutral ? 0 : 35;
    if (forShade === 'dark') {
      return {
        bg: hslToHex(h, sA, 6), surface: hslToHex(h, sB, 10), surface2: hslToHex(h, sC, 14),
        border: hslToHex(h, sD, 23), text: hslToHex(h, sE, 95), muted: hslToHex(h, sE, 65)
      };
    }
    return {
      bg: hslToHex(h, sA, 97), surface: '#ffffff', surface2: hslToHex(h, sC, 95),
      border: hslToHex(h, sD, 83), text: hslToHex(h, sF, 15), muted: hslToHex(h, sE, 46)
    };
  }

  function colorsFor(key) {
    var t = THEMES[key] || THEMES[colorTheme];
    var swapped = !!swaps[key];
    return swapped ? { primary: t.secondary, secondary: t.primary } : { primary: t.primary, secondary: t.secondary };
  }

  function hexToRgba(hex, alpha) {
    hex = hex.replace('#', '');
    var r = parseInt(hex.substr(0, 2), 16);
    var g = parseInt(hex.substr(2, 2), 16);
    var b = parseInt(hex.substr(4, 2), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
  }

  function apply() {
    var c = colorsFor(colorTheme);
    var palette = derivePalette(c.primary, shade);
    var accent = adjustAccent(c.secondary, shade);       // highlight slot: buttons, timers, prices
    var accentPurple = adjustStructural(c.primary, shade); // structural slot: borders, secondary buttons
    var root = document.documentElement;
    root.setAttribute('data-theme', shade);
    root.setAttribute('data-color-theme', colorTheme);
    root.style.setProperty('--bg', palette.bg);
    root.style.setProperty('--surface', palette.surface);
    root.style.setProperty('--surface2', palette.surface2);
    root.style.setProperty('--border', palette.border);
    root.style.setProperty('--text', palette.text);
    root.style.setProperty('--muted', palette.muted);
    root.style.setProperty('--accent', accent);
    root.style.setProperty('--accent-purple', accentPurple);
    // Decorative rgba glows (body backdrop, selected-card tint) so those
    // visibly shift with the theme too, not just solid borders/text.
    root.style.setProperty('--accent-glow', hexToRgba(accent, shade === 'light' ? 0.08 : 0.12));
    root.style.setProperty('--accent-purple-glow', hexToRgba(accentPurple, shade === 'light' ? 0.06 : 0.20));
  }

  apply(); // runs immediately at load — this file loads first in <head>, before body paints

  return {
    getShade: function () { return shade; },
    setShade: function (m) { shade = m === 'light' ? 'light' : 'dark'; apply(); save(); },
    getColorTheme: function () { return colorTheme; },
    setColorTheme: function (key) { if (THEMES[key]) { colorTheme = key; apply(); save(); } },
    isSwapped: function (key) { return !!swaps[key || colorTheme]; },
    toggleSwap: function (key) { key = key || colorTheme; swaps[key] = !swaps[key]; apply(); save(); },
    colorsFor: colorsFor,
    list: function () {
      return THEME_ORDER.map(function (key) {
        var c = colorsFor(key);
        return { key: key, name: THEMES[key].name, primary: c.primary, secondary: c.secondary };
      });
    }
  };
})();
