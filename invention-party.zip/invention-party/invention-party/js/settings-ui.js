// settings-ui.js — the Game Settings panel: game mode, rules, and
// presentation settings — the actual game rules. Host gets editable
// controls; everyone else gets a clear read-only summary. Sound and
// Appearance preferences live in the title screen's own Settings panel
// instead (see title.js) — they're per-device display preferences, not
// game rules, and are reachable before a game even starts.

var SettingsUI = (function () {
  var gearBtn, overlay, body;
  var isOpen = false;

  var TIME_OPTIONS = {
    problemTimeSec: [0, 60, 120, 180, 300],
    inventionTimeSec: [0, 120, 180, 300, 600],
    presentationTimeSec: [0, 60, 120, 180, 300],
    votingTimeSec: [0, 30, 60, 120, 180],
    wordTimerSec: [0, 15, 30, 60]
  };
  var ROUND_OPTIONS = [3, 5, 7, 10];
  var PROMPT_OPTIONS = [5, 7, 10];
  var SPEED_OPTIONS = ['fast', 'normal', 'slow'];

  var MODE_INFO = {
    classic: { icon: 'pen', title: 'Classic', desc: 'Write whatever problem you want, in your own words.' },
    madlibs_blind: { icon: 'eyeClosed', title: 'Mad Libs — Blind', desc: 'Fill in words one at a time without seeing the sentence they build.' },
    madlibs_live: { icon: 'eyeOpen', title: 'Mad Libs — Live', desc: 'See the sentence build itself in real time as you fill in the blanks.' }
  };

  function init() {
    gearBtn = document.getElementById('settingsGearBtn');
    overlay = document.getElementById('settingsPanelOverlay');
    body = document.getElementById('settingsPanelBody');
    gearBtn.innerHTML = Icons.settings();
    document.getElementById('settingsPanelCloseBtn').innerHTML = Icons.close();
  }

  function setVisible(visible) {
    gearBtn.style.display = visible ? 'flex' : 'none';
    if (!visible) close();
  }

  function open() { isOpen = true; overlay.classList.add('visible'); render(); }
  function close() { isOpen = false; overlay.classList.remove('visible'); }
  function refresh() { if (isOpen) render(); }

  function fmt(sec) {
    if (!sec) return 'No Timer';
    var m = Math.floor(sec / 60), s = sec % 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
  }

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function render() {
    var view = Game.getView();
    if (!view) { body.innerHTML = ''; return; }
    var isHost = Net.isHost();
    var s = view.settings;
    var locked = view.settingsLocked;
    var isMadlib = s.gameMode !== 'classic';

    var html = '<h2 style="margin-top:0;">' + Icons.settings() + ' Game Settings</h2>';

    if (!isHost) {
      html += renderReadOnly(s);
      body.innerHTML = html;
      return;
    }

    if (locked) html += '<div class="settings-lock-banner">' + Icons.lock() + ' Settings are locked until this game finishes</div>';

    // ---- GAME MODE ----
    html += '<div class="settings-section">';
    html += '<div class="settings-section-title">Game Mode</div>';
    html += '<div class="mode-cards">';
    GAME_MODE_ORDER.forEach(function (modeKey) {
      var info = MODE_INFO[modeKey];
      var selected = s.gameMode === modeKey;
      html += '<div class="mode-card' + (selected ? ' selected' : '') + (locked ? ' disabled' : '') + '" ' +
        (locked ? '' : 'onclick="App.hostUpdateSetting(\'gameMode\',\'' + modeKey + '\')"') + '>' +
        '<div class="mode-card-radio"></div>' +
        '<div><div class="mode-card-title">' + Icons[info.icon]() + ' ' + info.title + '</div>' +
        '<div class="mode-card-desc">' + info.desc + '</div></div>' +
        '</div>';
    });
    html += '</div></div>';

    // ---- GAME RULES ----
    html += '<div class="settings-section">';
    html += '<div class="settings-section-title">Game Rules</div>';
    if (isMadlib) {
      html += settingGroup(Icons.clock() + ' Word Timer', 'wordTimerSec', s.wordTimerSec, TIME_OPTIONS.wordTimerSec, locked);
      html += promptsGroup(s.numPrompts, locked);
    } else {
      html += settingGroup(Icons.clock() + ' Problem Time', 'problemTimeSec', s.problemTimeSec, TIME_OPTIONS.problemTimeSec, locked);
    }
    html += settingGroup(Icons.tool() + ' Invention Time', 'inventionTimeSec', s.inventionTimeSec, TIME_OPTIONS.inventionTimeSec, locked);
    html += settingGroup(Icons.ballot() + ' Voting Time', 'votingTimeSec', s.votingTimeSec, TIME_OPTIONS.votingTimeSec, locked);
    html += roundsGroup(s.rounds, locked);
    html += '</div>';

    // ---- PRESENTATION ----
    html += '<div class="settings-section">';
    html += '<div class="settings-section-title">Presentation</div>';
    html += '<p class="muted small" style="margin-top:0;">Each player picks AUTO or MANUAL when it\'s their turn to present their own invention.</p>';
    html += speedGroup(s.autoRevealSpeed, locked);
    html += settingGroup(Icons.mic() + ' Presentation Time (Manual only)', 'presentationTimeSec', s.presentationTimeSec, TIME_OPTIONS.presentationTimeSec, locked);
    html += '</div>';

    body.innerHTML = html;
  }

  function renderReadOnly(s) {
    var isMadlib = s.gameMode !== 'classic';
    var html = '<div class="settings-lock-banner">HOST ONLY — SETTINGS CAN ONLY BE CHANGED BY THE HOST</div>';
    html += '<div class="settings-section"><div class="settings-section-title">Game Mode</div>';
    html += '<div class="settings-summary">' + settingsRow(Icons[MODE_INFO[s.gameMode].icon]() + ' Mode', MODE_INFO[s.gameMode].title) + '</div></div>';

    html += '<div class="settings-section"><div class="settings-section-title">Game Rules</div><div class="settings-summary">';
    if (isMadlib) {
      html += settingsRow(Icons.clock() + ' Word Timer', fmt(s.wordTimerSec));
      html += settingsRow('# Prompts', s.numPrompts);
    } else {
      html += settingsRow(Icons.clock() + ' Problem Time', fmt(s.problemTimeSec));
    }
    html += settingsRow(Icons.tool() + ' Invention Time', fmt(s.inventionTimeSec));
    html += settingsRow(Icons.ballot() + ' Voting Time', fmt(s.votingTimeSec));
    html += settingsRow('Rounds', s.rounds);
    html += '</div></div>';

    html += '<div class="settings-section"><div class="settings-section-title">Presentation</div><div class="settings-summary">';
    html += settingsRow('Auto Reveal Speed', capitalize(s.autoRevealSpeed));
    html += settingsRow(Icons.mic() + ' Presentation Time', fmt(s.presentationTimeSec));
    html += '</div></div>';

    html += '<p class="muted small center" style="margin-top:14px;">' + Icons.lock() + ' Only the host can change these settings.</p>';
    return html;
  }

  function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }

  function settingsRow(label, value) {
    return '<div class="settings-row"><span>' + label + '</span><span class="settings-val">' + esc(value) + '</span></div>';
  }

  function settingGroup(label, key, current, options, locked) {
    var html = '<label>' + label + '</label><div class="pill-row">';
    options.forEach(function (sec) {
      var active = sec === current;
      html += '<button class="pill' + (active ? ' active' : '') + '" ' + (locked ? 'disabled' : '') +
        ' onclick="App.hostUpdateSetting(\'' + key + '\',' + sec + ')">' + (sec === 0 ? 'No Timer' : fmt(sec)) + '</button>';
    });
    html += '</div>';
    return html;
  }

  function speedGroup(current, locked) {
    var html = '<label>Auto Reveal Speed</label><div class="pill-row">';
    SPEED_OPTIONS.forEach(function (sp) {
      html += '<button class="pill' + (sp === current ? ' active' : '') + '" ' + (locked ? 'disabled' : '') +
        ' onclick="App.hostUpdateSetting(\'autoRevealSpeed\',\'' + sp + '\')">' + capitalize(sp) + '</button>';
    });
    html += '</div>';
    return html;
  }

  function promptsGroup(current, locked) {
    var isPreset = PROMPT_OPTIONS.indexOf(current) !== -1;
    var html = '<label>' + Icons.hash() + ' Number of Prompts</label><div class="pill-row">';
    PROMPT_OPTIONS.forEach(function (n) {
      html += '<button class="pill' + (n === current ? ' active' : '') + '" ' + (locked ? 'disabled' : '') +
        ' onclick="App.hostUpdateSetting(\'numPrompts\',' + n + ')">' + n + '</button>';
    });
    html += '<button class="pill' + (!isPreset ? ' active' : '') + '" ' + (locked ? 'disabled' : '') +
      ' onclick="SettingsUI.customPrompts()">Custom' + (!isPreset ? ' (' + current + ')' : '') + '</button>';
    html += '</div>';
    return html;
  }

  function roundsGroup(current, locked) {
    var isPreset = ROUND_OPTIONS.indexOf(current) !== -1;
    var html = '<label>' + Icons.hash() + ' Number of Rounds</label><div class="pill-row">';
    ROUND_OPTIONS.forEach(function (n) {
      html += '<button class="pill' + (n === current ? ' active' : '') + '" ' + (locked ? 'disabled' : '') +
        ' onclick="App.hostUpdateSetting(\'rounds\',' + n + ')">' + n + '</button>';
    });
    html += '<button class="pill' + (!isPreset ? ' active' : '') + '" ' + (locked ? 'disabled' : '') +
      ' onclick="SettingsUI.customRounds()">Custom' + (!isPreset ? ' (' + current + ')' : '') + '</button>';
    html += '</div>';
    return html;
  }

  function customRounds() {
    var view = Game.getView();
    var val = prompt('Custom number of rounds (1–30):', String(view ? view.settings.rounds : 3));
    if (val === null) return;
    var n = parseInt(val, 10);
    if (n >= 1 && n <= 30) App.hostUpdateSetting('rounds', n);
  }

  function customPrompts() {
    var view = Game.getView();
    var val = prompt('Custom number of prompts (3–20). Closest available template set will be used:', String(view ? view.settings.numPrompts : 5));
    if (val === null) return;
    var n = parseInt(val, 10);
    if (n >= 3 && n <= 20) App.hostUpdateSetting('numPrompts', n);
  }

  var GAME_MODE_ORDER = ['classic', 'madlibs_blind', 'madlibs_live'];

  return {
    init: init, open: open, close: close, setVisible: setVisible, refresh: refresh,
    customRounds: customRounds, customPrompts: customPrompts
  };
})();
