// icons.js — a small hand-built icon set (flat outline style, consistent
// stroke weight) to replace emoji as functional UI icons. Every icon uses
// stroke="currentColor" so it automatically follows text color / theme —
// no separate light/dark icon assets needed. No external icon library.

var Icons = (function () {
  function svg(inner) {
    return '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + inner + '</svg>';
  }

  return {
    // Settings — the classic "sliders" glyph (safer + more recognizable
    // than a literal gear at small sizes).
    settings: function () {
      return svg(
        '<line x1="4" y1="6" x2="20" y2="6"></line><circle cx="9" cy="6" r="2"></circle>' +
        '<line x1="4" y1="12" x2="20" y2="12"></line><circle cx="15" cy="12" r="2"></circle>' +
        '<line x1="4" y1="18" x2="20" y2="18"></line><circle cx="9" cy="18" r="2"></circle>'
      );
    },
    speakerOn: function () {
      return svg(
        '<polygon points="4,9 8,9 12,5 12,19 8,15 4,15"></polygon>' +
        '<path d="M15.5 8.5a4 4 0 0 1 0 7"></path><path d="M18 6a7.5 7.5 0 0 1 0 12"></path>'
      );
    },
    speakerOff: function () {
      return svg(
        '<polygon points="4,9 8,9 12,5 12,19 8,15 4,15"></polygon>' +
        '<line x1="17" y1="9" x2="23" y2="15"></line><line x1="23" y1="9" x2="17" y2="15"></line>'
      );
    },
    pen: function () {
      return svg('<polygon points="3,17 3,21 7,21 18,10 14,6"></polygon><line x1="14" y1="6" x2="18" y2="10"></line>');
    },
    eraser: function () {
      return svg('<rect x="7" y="9" width="14" height="8" rx="2" transform="rotate(-40 12 12)"></rect><line x1="3" y1="21" x2="13" y2="21"></line>');
    },
    undo: function () {
      return svg('<path d="M7 10A7 7 0 1 1 6 16"></path><polygon points="7,4 7,10 1,10"></polygon>');
    },
    redo: function () {
      return svg('<path d="M17 10A7 7 0 1 0 18 16"></path><polygon points="17,4 17,10 23,10"></polygon>');
    },
    trash: function () {
      return svg(
        '<line x1="4" y1="7" x2="20" y2="7"></line>' +
        '<line x1="6" y1="7" x2="7" y2="20"></line><line x1="18" y1="7" x2="17" y2="20"></line>' +
        '<line x1="7" y1="20" x2="17" y2="20"></line>' +
        '<line x1="9" y1="7" x2="9" y2="4"></line><line x1="15" y1="7" x2="15" y2="4"></line><line x1="9" y1="4" x2="15" y2="4"></line>'
      );
    },
    close: function () {
      return svg('<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>');
    },
    check: function () {
      return svg('<polyline points="20 6 9 17 4 12"></polyline>');
    },
    clock: function () {
      return svg('<circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline>');
    },
    tool: function () {
      return svg('<circle cx="7" cy="7" r="3"></circle><circle cx="17" cy="17" r="3"></circle><line x1="9.5" y1="9.5" x2="14.5" y2="14.5"></line>');
    },
    mic: function () {
      return svg(
        '<rect x="9" y="2" width="6" height="11" rx="3"></rect>' +
        '<path d="M5 10a7 7 0 0 0 14 0"></path><line x1="12" y1="19" x2="12" y2="22"></line><line x1="8" y1="22" x2="16" y2="22"></line>'
      );
    },
    ballot: function () {
      return svg('<rect x="3" y="8" width="18" height="12" rx="2"></rect><polyline points="8,13 11,16 16,10"></polyline><line x1="3" y1="8" x2="21" y2="8"></line>');
    },
    hash: function () {
      return svg('<line x1="4" y1="9" x2="20" y2="9"></line><line x1="4" y1="15" x2="20" y2="15"></line><line x1="10" y1="3" x2="8" y2="21"></line><line x1="16" y1="3" x2="14" y2="21"></line>');
    },
    lock: function () {
      return svg('<rect x="5" y="11" width="14" height="9" rx="2"></rect><path d="M8 11V8a4 4 0 0 1 8 0v3"></path>');
    },
    sun: function () {
      return svg(
        '<circle cx="12" cy="12" r="4"></circle>' +
        '<line x1="12" y1="2" x2="12" y2="4"></line><line x1="12" y1="20" x2="12" y2="22"></line>' +
        '<line x1="4.9" y1="4.9" x2="6.3" y2="6.3"></line><line x1="17.7" y1="17.7" x2="19.1" y2="19.1"></line>' +
        '<line x1="2" y1="12" x2="4" y2="12"></line><line x1="20" y1="12" x2="22" y2="12"></line>' +
        '<line x1="4.9" y1="19.1" x2="6.3" y2="17.7"></line><line x1="17.7" y1="6.3" x2="19.1" y2="4.9"></line>'
      );
    },
    moon: function () {
      return svg('<path d="M20 12.5A8 8 0 1 1 11.5 4 6.5 6.5 0 0 0 20 12.5Z"></path>');
    },
    image: function () {
      return svg('<rect x="3" y="3" width="18" height="18" rx="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline>');
    },
    play: function () {
      return svg('<circle cx="12" cy="12" r="9"></circle><polygon points="10,8 16,12 10,16"></polygon>');
    },
    eyeOpen: function () {
      return svg('<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"></path><circle cx="12" cy="12" r="3"></circle>');
    },
    eyeClosed: function () {
      return svg('<path d="M3 12s3.5-6 9-6 9 6 9 6"></path><line x1="4" y1="4" x2="20" y2="20"></line>');
    }
  };
})();
