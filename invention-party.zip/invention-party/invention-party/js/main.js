// main.js — glues Net + Game + UI together and exposes App.* for onclick handlers.
//
// RENDER STRATEGY (bug fix): a STATE update arrives from the host roughly
// once a second whenever a timer is running. Naively calling a full
// UI.renderX() on every single one of those would wipe out whatever the
// player is mid-typing (the problem textarea, the invention fields, a Mad
// Libs blank) or mid-drawing (the canvas gets re-initialized blank). So
// render() computes a "shape key" for the current screen; if the shape
// hasn't actually changed since the last full render, we only patch the
// timer countdown in place (UI.updateTimer) and leave the rest of the DOM —
// and whatever's in it — completely alone.
//
// Mad Libs' local, unsubmitted fill-in-progress (which template, which
// answers, how far through Blind mode's stepper) is transient client state
// that only main.js needs to know about — it's owned here, not in Game
// (which only cares about the final assembled string) or ui.js (pure render).

var App = (function () {
  var root;
  window.__roomCode = '';
  var lastPhaseKey = null;     // shape key of the last FULL render, for the skip-optimization above
  var lastPhaseSeen = null;    // raw phase, for phase-transition sound triggers
  var lastPlayerSnapshot = null; // id -> connected, for join/leave sound triggers
  var timerWasUrgent = false;  // so the warning beep fires once per crossing, not every tick
  var madlib = { template: null, answers: [], index: 0 }; // local fill-in-progress state
  var lastPresentIndexForSound = null;
  var lastPresentModeAtIndex = null;

  function init() {
    root = document.getElementById('app');
    UI.init(root);
    Game.setOnUpdate(onGameUpdate);
    UI.renderLanding();
    installGlobalSoundDelegation();
  }

  // Click + hover blips on every button/pill in the app, without having to
  // touch every single onclick handler individually.
  function installGlobalSoundDelegation() {
    var lastHoverEl = null;
    document.addEventListener('pointerover', function (e) {
      var btn = e.target.closest && e.target.closest('button, .pill, a.host-skip-link, .mode-card');
      if (btn && btn !== lastHoverEl && !btn.disabled) { lastHoverEl = btn; SFX.hover(); }
      if (!btn) lastHoverEl = null;
    }, true);
    document.addEventListener('click', function (e) {
      var btn = e.target.closest && e.target.closest('button, .pill, .mode-card');
      if (btn && !btn.disabled) SFX.click();
    }, true);
  }

  function currentName() {
    var el = document.getElementById('nameInput');
    return el ? el.value.trim() : '';
  }

  // ---------------- CREATE ----------------
  function createGame() {
    var name = currentName();
    if (!name) { SFX.error(); UI.renderLanding('Enter your name first.'); return; }
    UI.renderConnecting('Setting up your game');
    Net.on('message', function (peerId, data) { Game.hostHandleMessage(peerId, data); });
    Net.on('peerJoin', function (peerId) { Game.hostHandlePeerJoin(peerId); });
    Net.on('peerLeave', function (peerId) { Game.hostHandlePeerLeave(peerId); });
    Net.hostGame().then(function (code) {
      window.__roomCode = code;
      Game.hostInit(name);
      SFX.selfJoined();
    }).catch(function (err) {
      SFX.error();
      UI.renderLanding('Could not start hosting: ' + err.message);
    });
  }

  // ---------------- JOIN ----------------
  function joinGame() {
    var name = currentName();
    var code = (document.getElementById('codeInput').value || '').trim().toUpperCase();
    if (!name) { SFX.error(); UI.renderLanding('Enter your name first.'); return; }
    if (!code) { SFX.error(); UI.renderLanding('Enter the game code.'); return; }
    UI.renderConnecting('Connecting to game ' + code);
    Net.on('message', function (data) { Game.clientHandleMessage(data); });
    Net.on('hostLost', function () { SFX.error(); UI.renderLanding('Lost connection to the host. They may have closed their tab.'); });
    Net.joinGame(code).then(function () {
      window.__roomCode = code;
      Net.sendToHost({ type: 'JOIN', name: name });
    }).catch(function (err) {
      SFX.error();
      UI.renderLanding(err.message || 'Could not connect to that game.');
    });
  }

  function copyCode() {
    if (navigator.clipboard) navigator.clipboard.writeText(window.__roomCode);
  }

  function hostStart() {
    Game.hostStartGame();
  }

  function hostAdvance() {
    Game.hostAdvance();
  }

  // ---------------- SETTINGS ----------------
  function hostUpdateSetting(key, value) {
    if (!Net.isHost()) return;
    Game.hostUpdateSetting(key, value);
  }

  // ---------------- PRESENTATION ----------------
  function presenterChooseMode(mode) {
    Game.clientChoosePresentMode(mode);
    if (Net.isHost()) Game.hostHandleMessage(Game.getMeId(), { type: 'CHOOSE_PRESENT_MODE', mode: mode });
  }
  function hostForceNext() {
    Game.hostForceNextInvention();
  }
  function presenterShowField(field) {
    Game.clientShowField(field);
    if (Net.isHost()) Game.hostHandleMessage(Game.getMeId(), { type: 'SHOW_FIELD', field: field });
  }
  function presenterNextInvention() {
    Game.clientNextInvention();
    if (Net.isHost()) Game.hostHandleMessage(Game.getMeId(), { type: 'NEXT_INVENTION' });
  }

  // ---------------- PROBLEM PHASE: CLASSIC ----------------
  function submitProblem() {
    var text = document.getElementById('problemInput').value;
    if (!text.trim()) { SFX.error(); return; }
    sendProblemText(text);
  }

  function sendProblemText(text) {
    Game.clientSubmitProblem(text);
    if (Net.isHost()) Game.hostHandleMessage(Game.getMeId(), { type: 'SUBMIT_PROBLEM', text: text });
    SFX.submit();
  }

  // ---------------- PROBLEM PHASE: MAD LIBS ----------------
  function madlibBlindNext() {
    var input = document.getElementById('mlBlindInput');
    var val = input ? input.value.trim() : '';
    if (!val) { SFX.error(); return; }
    madlib.answers[madlib.index] = val;
    madlib.index++;
    render(); // shape key includes madlib.index, so this intentionally re-renders the next step
  }

  function madlibLiveInput(index, value) {
    madlib.answers[index] = value;
    var type = madlib.template ? madlib.template.blanks[index] : '';
    UI.madlibLivePatch(index, value, type); // direct DOM patch — no re-render, no lost focus
  }

  function madlibSubmit() {
    if (!madlib.template) return;
    var text = UI.assembleMadlib(madlib.template, madlib.answers);
    sendProblemText(text);
  }

  // ---------------- INVENT PHASE ----------------
  var INVENT_FIELD_IDS = { product: 'invProduct', name: 'invName', slogan: 'invSlogan', price: 'invPrice' };

  function setTool(t) {
    Drawing.setTool(t);
    document.getElementById('toolPen').classList.toggle('active', t === 'pen');
    document.getElementById('toolEraser').classList.toggle('active', t === 'eraser');
  }
  function setColor(c) { Drawing.setColor(c); }
  function setSize(s) {
    Drawing.setSize(s);
    var label = document.getElementById('brushSizeValue');
    if (label) label.textContent = s;
  }
  function adjustBrushSize(delta) {
    var slider = document.getElementById('sizeSlider');
    if (!slider) return;
    var v = Math.max(parseInt(slider.min, 10), Math.min(parseInt(slider.max, 10), parseInt(slider.value, 10) + delta));
    slider.value = v;
    setSize(v);
  }
  function undo() { Drawing.undo(); }
  function redo() { Drawing.redo(); }
  function clearCanvas() {
    if (confirm('Clear your drawing?')) Drawing.clear();
  }

  // Patches the progress dots/count in place (no re-render — same reasoning
  // as the timer patch: typing shouldn't cost focus) and clears the
  // error-highlight on whichever field the player is actively fixing.
  function onInventFieldInput(fieldId) {
    var el = document.getElementById(fieldId);
    if (el) el.classList.remove('field-error');
    var count = 0;
    Object.keys(INVENT_FIELD_IDS).forEach(function (key) {
      var input = document.getElementById(INVENT_FIELD_IDS[key]);
      var filled = !!(input && input.value.trim());
      if (filled) count++;
      var dot = document.querySelector('.progress-dot[data-field="' + key + '"]');
      if (dot) dot.classList.toggle('filled', filled);
    });
    var countEl = document.getElementById('inventProgressCount');
    if (countEl) countEl.textContent = count + ' / 4 complete';
  }

  function submitInvention() {
    var productEl = document.getElementById('invProduct');
    var nameEl = document.getElementById('invName');
    var slogan = document.getElementById('invSlogan').value;
    var price = document.getElementById('invPrice').value;
    var missing = [];
    if (!productEl.value.trim()) { productEl.classList.add('field-error'); missing.push('Product'); } else { productEl.classList.remove('field-error'); }
    if (!nameEl.value.trim()) { nameEl.classList.add('field-error'); missing.push('Name'); } else { nameEl.classList.remove('field-error'); }
    var errEl = document.getElementById('inventSubmitError');
    if (missing.length) {
      SFX.error();
      if (errEl) { errEl.textContent = 'Please fill in: ' + missing.join(', '); errEl.style.display = 'block'; }
      return;
    }
    if (errEl) errEl.style.display = 'none';
    var product = productEl.value, name = nameEl.value;
    var inv = { drawing: Drawing.exportPNG(), product: product, name: name, slogan: slogan, price: price };
    Game.clientSubmitInvention(inv);
    if (Net.isHost()) Game.hostHandleMessage(Game.getMeId(), {
      type: 'SUBMIT_INVENTION', drawing: inv.drawing, product: product, name: name, slogan: slogan, price: price
    });
    SFX.submit();
  }

  // ---------------- VOTE ----------------
  function submitVote(index) {
    Game.clientSubmitVote(index);
    if (Net.isHost()) Game.hostHandleMessage(Game.getMeId(), { type: 'SUBMIT_VOTE', targetIndex: index });
    SFX.voteSubmit();
  }

  // ---------------- SOUND: event detection off the synced view ----------------
  function handleEventSounds(view) {
    if (view.timerExpired) SFX.timerZero();

    if (view.timer && view.timer.remaining <= 10) {
      if (!timerWasUrgent) { SFX.timerWarning(); timerWasUrgent = true; }
    } else {
      timerWasUrgent = false;
    }

    if (lastPlayerSnapshot) {
      view.players.forEach(function (p) {
        var was = lastPlayerSnapshot[p.id];
        if (was === undefined) SFX.playerJoined();
        else if (was === true && p.connected === false) SFX.playerLeft();
      });
    }
    lastPlayerSnapshot = {};
    view.players.forEach(function (p) { lastPlayerSnapshot[p.id] = p.connected; });

    if (lastPhaseSeen !== null && lastPhaseSeen !== view.phase) {
      if (lastPhaseSeen === 'lobby' && view.phase === 'problem') SFX.gameStart();
      if (view.phase === 'vote' && lastPhaseSeen !== 'vote') SFX.votingOpen();
      if (view.phase === 'gameover') SFX.win();
    }
    lastPhaseSeen = view.phase;

    // Presentation is per-invention now (each presenter picks their own
    // AUTO/MANUAL), so "presentation started" is the moment a mode gets
    // chosen for the current invention, not a phase transition.
    if (view.phase === 'presenting' && view.presentation) {
      var idx = view.presentation.index;
      if (lastPresentIndexForSound !== idx) { lastPresentModeAtIndex = null; lastPresentIndexForSound = idx; }
      if (view.presentation.mode && !lastPresentModeAtIndex) SFX.presentationStart();
      lastPresentModeAtIndex = view.presentation.mode;
    }
  }

  // ---------------- RENDER DISPATCH ----------------
  function onGameUpdate(errInfo) {
    if (errInfo && errInfo.joinRejected) { SFX.error(); SettingsUI.setVisible(false); UI.renderLanding(errInfo.joinRejected); return; }
    if (errInfo && errInfo.kicked) { SettingsUI.setVisible(false); UI.renderLanding('You were removed from the game.'); return; }
    var view = Game.getView();
    if (view) handleEventSounds(view);
    render();
  }

  // The "shape" of the current screen — used to decide whether a re-render
  // would actually change anything besides the timer. Phases with no
  // persistent user input (lobby, creatorReveal, leaderboard, gameover)
  // always fully re-render (no data to lose there).
  function computeShapeKey(view) {
    if (view.phase === 'problem') {
      var key = 'problem:' + view.iSubmittedProblem;
      if (view.settings.gameMode !== 'classic') key += ':' + madlib.index; // stepper progress forces a re-render on Next
      return key;
    }
    if (view.phase === 'invent') return 'invent:' + view.iSubmittedInvention;
    if (view.phase === 'vote') return 'vote:' + view.iVoted;
    if (view.phase === 'presenting') {
      var r = view.presentation.revealed;
      var fieldsKey = (r.drawing ? 1 : 0) + '' + (r.product ? 1 : 0) + (r.name ? 1 : 0) + (r.slogan ? 1 : 0) + (r.price ? 1 : 0);
      return 'presenting:' + view.presentation.index + ':' + view.presentation.mode + ':' + fieldsKey;
    }
    return null; // null = always fully render this phase
  }

  // Resets the local Mad Libs fill-in-progress whenever the host hands us a
  // freshly-assigned template (a new round, or first entry into 'problem').
  function syncMadlibState(view) {
    if (view.phase !== 'problem' || view.settings.gameMode === 'classic' || !view.madlib) return;
    if (!madlib.template || madlib.template.text !== view.madlib.text) {
      madlib = { template: view.madlib, answers: new Array(view.madlib.blanks.length).fill(''), index: 0 };
    }
  }

  function render() {
    var view = Game.getView();
    if (!view) { SettingsUI.setVisible(false); UI.renderConnecting('Waiting for game data'); return; }
    SettingsUI.setVisible(true);
    SettingsUI.refresh();
    syncMadlibState(view);

    var key = computeShapeKey(view);
    if (key !== null && key === lastPhaseKey) {
      // Same screen already on-screen — only the timer (or something inert
      // like another player's submitted-count) changed. Patch the timer in
      // place so any in-progress typing/drawing is left untouched.
      UI.updateTimer(view);
      return;
    }
    lastPhaseKey = key;

    var isHost = Net.isHost();
    var meId = Game.getMeId();
    switch (view.phase) {
      case 'lobby': UI.renderLobby(view, isHost, meId); break;
      case 'problem': UI.renderProblem(view, madlib); break;
      case 'invent': UI.renderInvent(view); break;
      case 'presenting': UI.renderPresenting(view, isHost); break;
      case 'vote': UI.renderVote(view); break;
      case 'creatorReveal': UI.renderCreatorReveal(view, isHost); break;
      case 'leaderboard': UI.renderLeaderboard(view, isHost); break;
      case 'gameover': UI.renderGameOver(view); break;
      default: UI.renderConnecting('Loading');
    }
  }

  return {
    init: init,
    createGame: createGame,
    joinGame: joinGame,
    copyCode: copyCode,
    hostStart: hostStart,
    hostAdvance: hostAdvance,
    hostUpdateSetting: hostUpdateSetting,
    presenterChooseMode: presenterChooseMode,
    hostForceNext: hostForceNext,
    presenterShowField: presenterShowField,
    presenterNextInvention: presenterNextInvention,
    submitProblem: submitProblem,
    madlibBlindNext: madlibBlindNext,
    madlibLiveInput: madlibLiveInput,
    madlibSubmit: madlibSubmit,
    setTool: setTool,
    setColor: setColor,
    setSize: setSize,
    adjustBrushSize: adjustBrushSize,
    undo: undo,
    redo: redo,
    clearCanvas: clearCanvas,
    onInventFieldInput: onInventFieldInput,
    submitInvention: submitInvention,
    submitVote: submitVote
  };
})();

window.addEventListener('DOMContentLoaded', function () {
  Title.init();
  SettingsUI.init();
  App.init();
});
