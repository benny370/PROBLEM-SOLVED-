// sfx.js — lightweight UI sound effects, entirely synthesized with the Web
// Audio API (short oscillator "blips"). No audio files to ship, so this
// works the moment the folder is opened, and every sound is fully original.
// Personal preference (not a game rule), so it's NOT part of Game/Net state —
// each player just toggles their own copy on/off, saved locally.

var SFX = (function () {
  var ctx = null;
  var enabled = true;

  try {
    var stored = localStorage.getItem('sfxEnabled');
    if (stored !== null) enabled = stored === '1';
  } catch (e) { /* localStorage unavailable — default stays on */ }

  function ensureCtx() {
    if (!ctx) {
      try { ctx = new (window.AudioContext || window.webkitAudioContext)(); }
      catch (e) { ctx = null; }
    }
    if (ctx && ctx.state === 'suspended') ctx.resume().catch(function () {});
    return ctx;
  }
  // Browsers block audio until a user gesture — this catches the very first
  // click/tap/keypress anywhere and warms the audio context up for later.
  ['click', 'keydown', 'touchstart'].forEach(function (evt) {
    document.addEventListener(evt, function () { ensureCtx(); }, { once: true, passive: true });
  });

  function tone(freq, duration, opts) {
    if (!enabled) return;
    opts = opts || {};
    var c = ensureCtx();
    if (!c) return;
    var t0 = c.currentTime;
    var osc = c.createOscillator();
    var gain = c.createGain();
    osc.type = opts.type || 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    if (opts.slideTo) osc.frequency.exponentialRampToValueAtTime(opts.slideTo, t0 + duration);
    var peak = opts.volume != null ? opts.volume : 0.16;
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(peak, t0 + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    osc.connect(gain).connect(c.destination);
    osc.start(t0);
    osc.stop(t0 + duration + 0.03);
  }

  function sequence(notes) {
    if (!enabled) return;
    notes.forEach(function (n) {
      setTimeout(function () { tone(n.freq, n.duration, n.opts); }, n.delay || 0);
    });
  }

  return {
    isEnabled: function () { return enabled; },
    setEnabled: function (v) {
      enabled = !!v;
      try { localStorage.setItem('sfxEnabled', enabled ? '1' : '0'); } catch (e) {}
    },

    click: function () { tone(520, 0.05, { type: 'square', volume: 0.09 }); },
    hover: function () { tone(760, 0.03, { type: 'sine', volume: 0.04 }); },
    selfJoined: function () { sequence([{ freq: 523, duration: 0.08 }, { freq: 659, duration: 0.08, delay: 90 }, { freq: 784, duration: 0.16, delay: 180 }]); },
    playerJoined: function () { sequence([{ freq: 440, duration: 0.08 }, { freq: 660, duration: 0.12, delay: 70 }]); },
    playerLeft: function () { sequence([{ freq: 440, duration: 0.1, opts: { type: 'triangle' } }, { freq: 300, duration: 0.16, delay: 80, opts: { type: 'triangle' } }]); },
    gameStart: function () { sequence([{ freq: 392, duration: 0.1 }, { freq: 523, duration: 0.1, delay: 110 }, { freq: 659, duration: 0.1, delay: 220 }, { freq: 784, duration: 0.24, delay: 330 }]); },
    submit: function () { sequence([{ freq: 600, duration: 0.07 }, { freq: 900, duration: 0.11, delay: 80 }]); },
    presentationStart: function () { sequence([{ freq: 330, duration: 0.13, opts: { type: 'sawtooth', volume: 0.1 } }, { freq: 494, duration: 0.18, delay: 130, opts: { type: 'sawtooth', volume: 0.1 } }]); },
    votingOpen: function () { sequence([{ freq: 587, duration: 0.1 }, { freq: 740, duration: 0.15, delay: 110 }]); },
    voteSubmit: function () { tone(700, 0.09, { type: 'square', volume: 0.13 }); },
    timerWarning: function () { tone(880, 0.09, { type: 'square', volume: 0.13 }); },
    timerZero: function () { sequence([{ freq: 220, duration: 0.16, opts: { type: 'sawtooth', volume: 0.15 } }, { freq: 165, duration: 0.26, delay: 140, opts: { type: 'sawtooth', volume: 0.15 } }]); },
    win: function () { sequence([{ freq: 523, duration: 0.13 }, { freq: 659, duration: 0.13, delay: 120 }, { freq: 784, duration: 0.13, delay: 240 }, { freq: 1047, duration: 0.32, delay: 360 }]); },
    error: function () { sequence([{ freq: 220, duration: 0.12, opts: { type: 'square', volume: 0.12 } }, { freq: 180, duration: 0.17, delay: 100, opts: { type: 'square', volume: 0.12 } }]); }
  };
})();
