// net.js — WebRTC peer connections via the free public PeerJS broker.
// The host's tab is the authority for the game session; clients connect
// directly to the host over a WebRTC data channel. No installed server,
// no accounts — just two (or more) browsers open at once.

var Net = (function () {
  var peer = null;
  var isHostFlag = false;
  var hostConn = null;          // client -> connection to host
  var clientConns = {};         // host -> map of peerId -> DataConnection
  var myId = null;
  var handlers = {};            // event name -> callback

  var CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  function randomCode(len) {
    len = len || 4;
    var s = '';
    for (var i = 0; i < len; i++) s += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
    return s;
  }
  function fullId(code) { return 'problem-child-game-' + code; }

  function on(evt, fn) { handlers[evt] = fn; }
  function fire(evt) {
    var args = Array.prototype.slice.call(arguments, 1);
    if (handlers[evt]) handlers[evt].apply(null, args);
  }

  function hostGame() {
    return new Promise(function (resolve, reject) {
      isHostFlag = true;
      attemptHost(resolve, reject, 0);
    });
  }

  function attemptHost(resolve, reject, tries) {
    if (tries > 6) { reject(new Error('Could not get a free room code right now. Please try again.')); return; }
    var code = randomCode(4);
    var p = new Peer(fullId(code), { debug: 0 });
    p.on('open', function (id) {
      peer = p; myId = id;
      wireHostEvents();
      resolve(code);
    });
    p.on('error', function (err) {
      if (err.type === 'unavailable-id') {
        p.destroy();
        attemptHost(resolve, reject, tries + 1);
      } else {
        reject(err);
      }
    });
  }

  function wireHostEvents() {
    peer.on('connection', function (conn) {
      conn.on('open', function () {
        clientConns[conn.peer] = conn;
        fire('peerJoin', conn.peer);
      });
      conn.on('data', function (data) {
        fire('message', conn.peer, data);
      });
      conn.on('close', function () {
        delete clientConns[conn.peer];
        fire('peerLeave', conn.peer);
      });
      conn.on('error', function () {});
    });
    peer.on('disconnected', function () { fire('hostNetworkLost'); });
  }

  function joinGame(code) {
    return new Promise(function (resolve, reject) {
      isHostFlag = false;
      var p = new Peer(undefined, { debug: 0 });
      var settled = false;
      p.on('open', function (id) {
        peer = p; myId = id;
        var conn = p.connect(fullId(code), { reliable: true });
        var timeout = setTimeout(function () {
          if (!settled) { settled = true; reject(new Error('No response from that game code. Double-check it and make sure the host still has their tab open.')); }
        }, 9000);
        conn.on('open', function () {
          if (settled) return;
          hostConn = conn;
          settled = true; clearTimeout(timeout);
          conn.on('data', function (data) { fire('message', data); });
          conn.on('close', function () { fire('hostLost'); });
          resolve();
        });
        conn.on('error', function (err) {
          if (!settled) { settled = true; clearTimeout(timeout); reject(err); }
        });
      });
      p.on('error', function (err) {
        if (!settled) { settled = true; reject(err); }
      });
    });
  }

  function sendToHost(msg) { if (hostConn) hostConn.send(msg); }
  function sendTo(peerId, msg) { if (clientConns[peerId]) clientConns[peerId].send(msg); }
  function kick(peerId) { if (clientConns[peerId]) clientConns[peerId].close(); delete clientConns[peerId]; }
  function myPeerId() { return myId; }

  return {
    hostGame: hostGame,
    joinGame: joinGame,
    sendToHost: sendToHost,
    sendTo: sendTo,
    kick: kick,
    myPeerId: myPeerId,
    on: on,
    isHost: function () { return isHostFlag; }
  };
})();
